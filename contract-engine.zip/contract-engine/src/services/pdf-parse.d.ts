declare module 'pdf-parse' {
  const pdf: (buffer: Buffer | Uint8Array) => Promise<{ text: string }>;
  export default pdf;
}

