import * as fs from 'fs/promises';
import * as path from 'path';

export async function validateFileAttributes(fileName: string): Promise<{ allChecksPass: boolean, results: Array<{ check: string, result: boolean }> }> {
  const maxFileSize = parseInt(process.env.MAX_FILE_SIZE || '5242880'); // Example: 5 MB limit
  const fileDirectory = './files';  // Local directory where files are stored
  const recencyThresholdMs = 30 * 1000;  // 30 seconds

  let results: Array<{ check: string, result: boolean }> = [];
  const filePath = path.join(fileDirectory, fileName);

  try {
    // Step 1: Check if the file exists and fetch metadata
    const stats = await fs.stat(filePath);

    // Check if the ContentType is 'application/pdf'
    const isContentTypePDF = path.extname(filePath).toLowerCase() === '.pdf';
    results.push({ check: 'Is PDF', result: isContentTypePDF });

    // Step 2: Check if the file size is under the maximum allowed size
    const fileSize = stats.size;
    const isFileSizeUnderLimit = fileSize <= maxFileSize;
    results.push({ check: `File size under ${maxFileSize} bytes`, result: isFileSizeUnderLimit });

    // Step 3: Check if the file was modified within the last 30 seconds
    const lastModified = stats.mtimeMs;
    const isFileRecent = (Date.now() - lastModified) <= recencyThresholdMs;
    results.push({ check: 'File is recent (within 30 seconds)', result: isFileRecent });

    // Step 4: Detect compression types (ZIP, RAR, etc.)
    const fileExtension = path.extname(filePath).toLowerCase();
    const isCompressed = ['zip', 'rar', '7z', 'tar', 'gz'].includes(fileExtension);
    results.push({ check: 'File is not a compressed archive', result: !isCompressed });

    // Step 5: Fetch the first few bytes (magic number) of the file to verify it's a PDF
    const fileHandle = await fs.open(filePath, 'r');
    const buffer = Buffer.alloc(5);
    await fileHandle.read(buffer, 0, 5, 0);
    await fileHandle.close();

    const fileHeader = buffer.toString();
    const isMagicNumberPDF = fileHeader.startsWith('%PDF');
    results.push({ check: 'Magic number is PDF', result: isMagicNumberPDF });

    // Combine the results to determine if all checks pass
    const allChecksPass = results.every(check => check.result === true);

    return { allChecksPass, results };

  } catch (error: any) {
    if (error.code === 'ENOENT') {
      console.error(`File not found: ${filePath}`);
    } else {
      console.error('Error in checkFileAttributes:', error);
    }
    results.push({ check: 'Error encountered', result: false });
    return { allChecksPass: false, results };  // Return false if there was an error
  }
}