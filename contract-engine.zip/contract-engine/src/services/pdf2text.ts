import fs from 'fs';
import path from 'path';
import pdfParse from 'pdf-parse';

/**
 * Converts a PDF file to a text file.
 * 
 * @param {string} sourcePath - The path to the source PDF file.
 * @param {string} destinationPath - The path to save the extracted text.
 * @returns {Promise<void>} - A promise that resolves when the text file is created.
 */
export const extractText = async (sourcePath: string, destinationPath: string): Promise<void> => {
  try {
    // Ensure the destination directory exists
    const dir = path.dirname(destinationPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // Read the PDF file as a buffer
    const dataBuffer = fs.readFileSync(sourcePath);

    // Extract text from the PDF
    const data = await pdfParse(dataBuffer);
    
    // Write the extracted text to the destination file
    fs.writeFileSync(destinationPath, data.text, 'utf8');
    // console.log(`Text extracted and saved to ${destinationPath}`);
  } catch (error) {
    console.error('Error during PDF to text conversion:', error);
    throw error;
  }
};
