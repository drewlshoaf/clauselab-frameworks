import * as dotenv from 'dotenv';
dotenv.config();

import * as fs from 'fs/promises';
import { watch } from 'fs';
import * as path from 'path';

// Import the combined file
import { fetchOpenAIResponse, validateFileAttributes, extractText, validateContentGPT, getReportPrompt } from './test';

// Validation rules directly in the script
const content_validation_rules = {
  "isLegible": true,
  "percentLegible": 90,
  "isAContract": true,
  "percentContract": 90,
  "contractTypeCode": ["residential-lease", "commercial-lease", "non-disclosure", "employment"],
  "language": ["English"]
};

// Directory to monitor
const directoryToWatch = './files';

// Function to validate the OpenAI response against rules
const validateAgainstRules = (openAIResponse: any, rules: any): boolean => {
  let allChecksPass = true;

  // Validate each rule
  for (const [key, rule] of Object.entries(rules)) {
    const value = openAIResponse[key];
    let pass = false;

    if (Array.isArray(rule)) {
      pass = rule.includes(value); // Check if the value is in the array
    } else if (typeof rule === 'number') {
      pass = value >= rule; // Check if the value meets the minimum threshold
    } else {
      pass = value === rule; // Check for exact match
    }

    console.log(`Check for ${key}: ${pass ? 'Passed' : 'Failed'}`);
    if (!pass) allChecksPass = false;
  }

  return allChecksPass;
};

// Function to process the newly detected file
const processFile = async (fileName: string) => {
  try {
    console.log(`New file detected: ${fileName}, processing...`);

    const filePath = path.join(directoryToWatch, fileName);

    // Check file attributes
    const { allChecksPass, results } = await validateFileAttributes(fileName);
    results.forEach((result: { check: any; result: any; }) => console.log(`${result.check}: ${result.result}`));

    if (allChecksPass) {
      console.log('All checks passed, proceeding...');

      const filePrefix = fileName.replace('.pdf', '');
      const outputDir = `./output/${filePrefix}`;
      await fs.mkdir(outputDir, { recursive: true });

      const textFilePath = path.join(outputDir, 'contract_text.txt');
      await extractText(filePath, textFilePath);
      const extractedText = await fs.readFile(textFilePath, 'utf8');

      // Send the text to OpenAI for content validation
      const prompt_validateContentGPT = await validateContentGPT(extractedText);
      const openAIResponse = await fetchOpenAIResponse(prompt_validateContentGPT);

      // Parse the response if necessary
      const parsedOpenAIResponse = typeof openAIResponse === 'string' ? JSON.parse(openAIResponse) : openAIResponse;

      // Save OpenAI response to a JSON file
      const jsonResponsePath = path.join(outputDir, 'content_validation.json');
      await fs.writeFile(jsonResponsePath, JSON.stringify(parsedOpenAIResponse, null, 2), 'utf8');
      console.log(`OpenAI response saved to ${jsonResponsePath}`);

      // Validate the OpenAI response against the rules
      const validationPassed = validateAgainstRules(parsedOpenAIResponse, content_validation_rules);
      console.log(validationPassed ? 'Content validation passed.' : 'Content validation failed.');

      if (validationPassed) {
        // Get the contractTypeCode from the OpenAI response
        const contractTypeCode = parsedOpenAIResponse.contractTypeCode;

        if (content_validation_rules.contractTypeCode.includes(contractTypeCode)) {
          // Generate the report
          console.log(`Generating report for contract type: ${contractTypeCode}`);
          const reportPrompt = await getReportPrompt(contractTypeCode, extractedText);
          const reportResponse = await fetchOpenAIResponse(reportPrompt);

          // Save the report response to a JSON file
          const reportResponsePath = path.join(outputDir, 'report.json');
          await fs.writeFile(reportResponsePath, JSON.stringify(reportResponse, null, 2), 'utf8');
          console.log(`Report response saved to ${reportResponsePath}`);
        } else {
          console.log(`No valid contract type found for report generation.`);
        }
      }
    } else {
      console.log('Some checks failed, skipping further processing.');
    }
  } catch (error) {
    console.error('Error processing file:', error);
  }
};

// Function to monitor the directory for changes
const monitorDirectory = async (directory: string) => {
  console.log(`Watching directory: ${directory}`);
  
  // Watch the directory for new files
  watch(directory, async (eventType, fileName) => {
    if (eventType === 'rename' && fileName && fileName.endsWith('.pdf')) {
      const filePath = path.join(directory, fileName);
      
      try {
        // Check if the file exists and is accessible (new file creation triggers "rename" event)
        const stats = await fs.stat(filePath);
        if (stats.isFile()) {
          // If the file exists, process it
          await processFile(fileName);
        }
      } catch (err) {
        // File might have been removed, ignore the error
        console.log(`File not found or no longer exists: ${fileName}`);
      }
    }
  });
};

// Start monitoring the directory
monitorDirectory(directoryToWatch).catch(err => console.error('Error setting up directory monitoring:', err));
