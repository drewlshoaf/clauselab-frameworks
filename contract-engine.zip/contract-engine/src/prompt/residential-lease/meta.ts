export interface MetaDetails {
  [key: string]: string;
}

export interface MetaSection {
  [section: string]: MetaDetails[];
}

export const meta: MetaSection = {
  "Introduction": [
    { "Title": "Residential Lease Agreement" },
    { "Date": "The date the agreement is made" },
    { "Landlord": "Name of the landlord" },
    { "Tenant": "Names of the tenant(s)" },
  ],
  "Premises": [
    { "Description of Property": "Full address, type of property (e.g., single-family home, apartment), and any specific unit number or description." },
  ],
  "Term of Lease": [
    { "Start Date": "When the lease begins" },
    { "End Date": "When the lease ends" },
    { "Renewal Terms": "Conditions for renewal or extension of the lease" },
  ],
  "Rent": [
    { "Amount": "Monthly rent amount" },
    { "Due Date": "When rent is due (e.g., first day of each month)" },
    { "Payment Method": "Accepted forms of payment (e.g., check, online transfer)" },
    { "Late Fees": "Penalties for late payment, including amount and when they apply" },
  ],
  "Security Deposit": [
    { "Amount": "Amount of the security deposit" },
    { "Conditions for Return": "Terms under which the deposit will be returned or withheld" },
  ],
  "Utilities and Services": [
    { "Responsibility": "Who is responsible for paying which utilities (e.g., water, electricity, gas)" },
    { "Included Services": "Any services included in the rent (e.g., trash removal, lawn care)" },
  ],
  "Maintenance and Repairs": [
    { "Landlord's Responsibilities": "What the landlord is responsible for maintaining and repairing" },
    { "Tenant's Responsibilities": "What the tenant is responsible for maintaining and repairing" },
    { "Reporting Issues": "How and when the tenant should report maintenance issues" },
  ],
  "Use of Premises": [
    { "Permitted Use": "Residential use only, any restrictions on use" },
    { "Prohibited Activities": "Activities that are not allowed (e.g., illegal activities, commercial use)" },
  ],
  "Occupants": [
    { "Authorized Tenants": "Names of all individuals authorized to live on the premises" },
    { "Guest Policy": "Rules regarding guests, including duration of stay" },
  ],
  "Furnishings and Appliances": [
    { "Provided Items": "List of furnishings and appliances provided by the landlord" },
    { "Condition": "Condition of items at the start of the lease" },
  ],
  "Pet Policy": [
    { "Permission": "Whether pets are allowed" },
    { "Restrictions": "Types and number of pets allowed" },
    { "Fees and Deposits": "Any additional fees or deposits required for pets" },
  ],
  "Insurance": [
    { "Tenant Insurance": "Requirement for tenant to have renter’s insurance" },
    { "Landlord Insurance": "Landlord’s insurance responsibilities" },
  ],
  "Alterations and Improvements": [
    { "Permission": "Requirement for tenant to get written consent before making alterations" },
    { "Restoration": "Requirement for tenant to restore premises to original condition upon lease termination" },
  ],
  "Entry by Landlord": [
    { "Notice": "Amount of notice the landlord must give before entering the premises" },
    { "Permitted Reasons": "Reasons the landlord may enter the premises (e.g., repairs, inspections)" },
  ],
  "Subleasing and Assignment": [
    { "Permission": "Whether subleasing or assignment is allowed" },
    { "Conditions": "Conditions under which subleasing or assignment is permitted" },
  ],
  "Default and Termination": [
    { "Default Conditions": "Conditions that constitute a default by the tenant" },
    { "Remedies": "Landlord’s remedies in case of tenant default" },
    { "Early Termination": "Conditions under which the lease can be terminated early" },
  ],
  "Military Clause": [
    { "Termination": "Rights of military personnel to terminate the lease early due to relocation or deployment" },
  ],
  "Dispute Resolution": [
    { "Mediation/Arbitration": "Methods for resolving disputes between landlord and tenant" },
    { "Jurisdiction": "Legal jurisdiction governing the lease" },
  ],
  "Notices": [
    { "Addresses": "Addresses where notices should be sent for both landlord and tenant" },
    { "Method": "Accepted methods for delivering notices (e.g., mail, email)" },
  ],
  "Miscellaneous": [
    { "Severability": "Statement that if one part of the lease is invalid, the rest remains in effect" },
    { "Entire Agreement": "Statement that the lease constitutes the entire agreement between the parties" },
    { "Amendments": "Conditions under which the lease can be amended (usually requires written consent of both parties)" },
    { "Waiver": "Conditions under which rights or provisions may be waived" },
  ],
  "Signatures": [
    { "Landlord’s Signature": "Signature and date" },
    { "Tenant’s Signature": "Signature and date" },
    { "Witnesses/Notarization": "If required by state law or landlord preference" },
  ],
  "Jurisdictions": [
    { "Country": "The country where the agreement is applicable" },
    { "State/Province": "The state or province where the agreement is applicable" },
    { "City": "The city where the agreement is applicable" },
  ]
};