import { meta, MetaSection } from './meta';

// Function to process metadata into a structured format
export const metadata = (meta: MetaSection) => {
  return Object.entries(meta).map(([section, details]) => {
    return {
      section,
      details: details.map(item => {
        const key = Object.keys(item)[0];
        return { [key]: item[key] };
      }),
    };
  });
};

/**
 * Generates the prompt to be sent to OpenAI's API
 * 
 * @param {string} contractText - The text of the residential lease agreement.
 * @returns {string} - The structured prompt to send to the API.
 */
export const prompt = (contractText: string): string => {
  const processedMetadata = metadata(meta);

  return `
You are an objective advisor reviewing a residential lease agreement.

Identify risks for both the landlord and tenant, classified as low, medium, or high.

Summarize each risk with a title, detailed description, and steps to mitigate the risk.

Additionally, extract key metadata from the contract and provide it in the form of a structured JSON document.

Return the JSON object only, formatted according to this schema:
{
  "metadata": {
    "contractType": "residential-lease",
    "parties": [
      {
        "name": "landlord",
        "executiveSummary": "",
        "risks": [
          {
            "title": "",
            "description": "",
            "classification": "low | medium | high",
            "remediation": [""]
          }
        ]
      },
      {
        "name": "tenant",
        "executiveSummary": "",
        "risks": [
          {
            "title": "",
            "description": "",
            "classification": "low | medium | high",
            "remediation": [""]
          }
        ]
      }
    ]
  }
}

Residential lease agreement: ${contractText}
  `;
};