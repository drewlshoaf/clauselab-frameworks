import * as fs from 'fs/promises';
import * as path from 'path';

// Function to get contract codes from the local contracts.json file
export const contractCodes = async (): Promise<string> => {
    const contractsFilePath: string = path.join(__dirname, '../sysfiles/contracts.json');
    
    try {
        // Read the contracts.json file
        const fileContent = await fs.readFile(contractsFilePath, 'utf-8');
        
        // Parse the JSON content
        const contractsData = JSON.parse(fileContent);

        // Extract contract codes from the contracts array
        const codes = contractsData.contracts.map((contract: any) => contract.code);

        // Return unique contract codes as a comma-separated string
        return Array.from(new Set(codes)).join(',');
    } catch (err) {
        console.error('Failed to load contracts.json from the filesystem', err);
        throw err;
    }
};

export const validateContentGPT = async (contractText: string) => {
    // Fetch contract codes from the local JSON file
    const contractTypeCodes = await contractCodes();

    // Return the prompt for GPT processing
    return `
      Please examine this document:
      
      ${contractText}
      
      and return a JSON response with the following fields:
  
      1. **isLegible**: Analyze the text content of the attached PDF and determine if the text is readable. Return true if it is legible, otherwise return false.
      
      2. **percentLegible**: Estimate the percentage (from 0 to 100) of the document's text that is readable.
      
      3. **isAContract**: Determine whether the document's text constitutes a contract. Return true if the document is a contract, otherwise return false.
      
      4. **percentContract**: Estimate the percentage (from 0 to 100) of the document that is part of a contract.
      
      5. **contractTypeCode**: Identify the type of contract the document represents by comparing it against this list: 
      
      ${contractTypeCodes}
      
      If no match is found, return null, otherwise, return the code which best represents the contract type.
      
      6. **language**: Identify the primary language used in the document.
      
      Please provide the result in the following JSON format:
  
      {
        "isLegible": boolean,
        "percentLegible": number,
        "isAContract": boolean,
        "percentContract": number,
        "contractTypeCode": string | null,
        "language": string
      }
    `;
};
