import dotenv from 'dotenv';
import express from 'express';
import { subscribeToKeyEvents } from './workflows/keyEventSubscriber';
import { loadContractsJson } from './services/contractService';

// Load environment variables
dotenv.config();

const app = express();
const port: number = parseInt(process.env.PORT || '4100');

// Start the Express server and the Redis listener
app.listen(port, async (): Promise<void> => {
  console.log(`Listening service is running on port ${port}`);

  // Load contracts.json into memory
  try {
    await loadContractsJson();
  } catch (err) {
    console.error('Error loading contracts.json at startup:', err);
  }

  subscribeToKeyEvents(); // Start listening for keyspace events
});
