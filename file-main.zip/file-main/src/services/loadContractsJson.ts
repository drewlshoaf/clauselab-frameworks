import { downloadS3TextFileToMemory } from "../services/s3Handler";

const bucketName: string = process.env.S3_BUCKET_NAME || 'clauselab';
const contractsKey: string = process.env.CONTRACTS_KEY || 'sysdocs/contracts.json';

export const contractCodes = async (): Promise<string> => {
    try {
      const fileContent = await downloadS3TextFileToMemory(bucketName, contractsKey);
      const contractsData = JSON.parse(fileContent);
      const codes = contractsData.contracts.map((contract: any) => contract.code);
      return Array.from(new Set(codes)).join(',');
    } catch (err) {
      console.error('Failed to load contracts.json into memory', err);
      throw err;
    }
};