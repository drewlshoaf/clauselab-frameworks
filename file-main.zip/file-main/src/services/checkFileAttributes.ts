import { S3Client, GetObjectCommand, HeadObjectCommand, GetObjectAclCommand } from '@aws-sdk/client-s3';
import { Readable } from 'stream';

export async function checkFileAttributes(account: string, key: string): Promise<{ allChecksPass: boolean, results: Array<{ check: string, result: boolean }> }> {
  const s3 = new S3Client({ region: process.env.AWS_REGION });
  const maxFileSize = parseInt(process.env.MAX_FILE_SIZE || '5242880'); // Example: 5 MB limit
  const bucketName = process.env.S3_BUCKET_NAME || 'clauselab'
  const recencyThresholdMs = 30 * 1000;  // 30 seconds

  let results = [];

  const s3ContractKey = `docs/${account}/${key}/1.pdf`;
  
  try {
    // Step 1: Fetch metadata from S3
    const headCommand = new HeadObjectCommand({
      Bucket: bucketName,
      Key: s3ContractKey,
    });

    const metadata = await s3.send(headCommand);

    // Check if the ContentType is 'application/pdf'
    const isContentTypePDF = metadata.ContentType === 'application/pdf';
    results.push({ check: 'Is PDF', result: isContentTypePDF || false });

    // Check file extension
    const fileExtension = s3ContractKey.split('.').pop()?.toLowerCase() ?? '';
    const isExtensionPDF = fileExtension === 'pdf';
    results.push({ check: 'File extension is PDF', result: isExtensionPDF });

    // Step 2: Check if the file size is under the maximum allowed size
    const fileSize = metadata.ContentLength || 0;
    const isFileSizeUnderLimit = fileSize <= maxFileSize;
    results.push({ check: `File size under ${maxFileSize} bytes`, result: isFileSizeUnderLimit });

    // Step 3: Check if the file was modified within the last 30 seconds
    const lastModified = metadata.LastModified ? new Date(metadata.LastModified) : undefined;
    const isFileRecent = lastModified && ((new Date()).getTime() - lastModified.getTime()) <= recencyThresholdMs;
    results.push({ check: 'File is recent (within 30 seconds)', result: isFileRecent || false });

    // Step 4: Detect compression types (ZIP, RAR, etc.)
    const isCompressed = ['zip', 'rar', '7z', 'tar', 'gz'].includes(fileExtension);
    results.push({ check: 'File is not a compressed archive', result: !isCompressed });

    // Step 5: Fetch the first few bytes (magic number)
    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: s3ContractKey,
      Range: 'bytes=0-4',  // Fetch first 5 bytes
    });

    const response = await s3.send(command);

    // Read the first few bytes of the file
    const stream = response.Body as Readable;
    const chunks = [];
    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const fileHeader = Buffer.concat(chunks).toString();

    // Check if the magic number matches PDF (%PDF)
    const isMagicNumberPDF = fileHeader.startsWith('%PDF');
    results.push({ check: 'Magic number is PDF', result: isMagicNumberPDF || false });

    // Step 6: Check if the file is encrypted
    const isEncrypted = metadata.ServerSideEncryption === 'AES256' || metadata.ServerSideEncryption === 'aws:kms';
    results.push({ check: 'File is encrypted', result: isEncrypted || false });

    // Step 7: Check if the file is private
    const aclCommand = new GetObjectAclCommand({
      Bucket: bucketName,
      Key: s3ContractKey,
    });
    const acl = await s3.send(aclCommand);
    const isPrivate = acl.Grants && acl.Grants.every(grant => grant.Grantee && grant.Permission !== 'READ' && grant.Grantee.URI !== 'http://acs.amazonaws.com/groups/global/AllUsers');
    results.push({ check: 'File is private', result: isPrivate || false });

    // Combine the results to determine if all checks pass
    const allChecksPass = results.every(check => check.result === true);

    return { allChecksPass, results };

  } catch (error: any) {
    if (error.name === 'NotFound') {
      console.error(`File not found: bucket = ${bucketName}, key = ${s3ContractKey}`);
    } else {
      console.error('Error in checkFileAttributes:', error);
    }
    results.push({ check: 'Error encountered', result: false });
    return { allChecksPass: false, results };  // Return false if there was an error
  }
}
