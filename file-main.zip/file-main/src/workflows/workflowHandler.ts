import { WORKFLOW_STATES } from './workflowStates';
import { checkFileAttributes } from '../services/checkFileAttributes';
import { pdf2Text } from '../services/pdf2text';
import { getPromptValidateContentProps } from '../prompt/validateContentProps';
import { getPromptTeaser } from '../prompt/teaser';
import { fetchOpenAIResponse } from '../services/chatGPT';
import { setRedisKey, getRedisKey } from '../services/redisService';
import { downloadS3File, uploadS3File, downloadS3TextFileToMemory } from '../services/s3Service';
import { Pool } from 'pg';

interface WorkflowContext {
  account: string;
  key: string;
  redisKey: string;
}

// Create a new PostgreSQL client pool
const pool = new Pool({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: parseInt(process.env.PG_PORT || '5432'),
  ssl: { rejectUnauthorized: false },
});

export const handleStateTransition = async (currentState: WORKFLOW_STATES, context: WorkflowContext): Promise<void> => {
  const { account, key, redisKey } = context;
  const contractKey = `contract_${account}_${key}`;

  try {
    console.log(`${currentState} - Starting workflow for account: ${account}, key: ${key}`);

    let docState: string | undefined;

    switch (currentState) {
      case WORKFLOW_STATES.INIT:
        console.log(`${currentState} - Initializing workflow for account ${account}, key ${key}`);
        await setRedisKey(redisKey, WORKFLOW_STATES.VALIDATE_PG);
        break;

      case WORKFLOW_STATES.VALIDATE_PG:
        console.log(`${currentState} - Validating and extracting PG data for account: ${account}, key: ${key}`);

        try {
          // Query the account table to check if the account exists and retrieve the plan
          const accountQuery = 'SELECT plan FROM account WHERE id = $1';
          const accountResult = await pool.query(accountQuery, [account]);

          if (accountResult.rowCount === 0) {
            console.error(`${currentState} - No account record found for account ${account}`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
            break;
          }

          const plan = accountResult.rows[0].plan;
          console.log(`${currentState} - Retrieved plan: ${plan} for account: ${account}`);

          // Store the plan in Redis for later use
          await setRedisKey(`plan_${account}`, plan);

          // Query the doc table to check if the document record exists and retrieve the state
          const docQuery = 'SELECT state FROM doc WHERE id = $1 AND account_id = $2';
          const docResult = await pool.query(docQuery, [key, account]);

          if (docResult.rowCount === 0) {
            console.error(`${currentState} - No doc record found for key ${key}`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
            break;
          }

          docState = docResult.rows[0].state;
          console.log(`${currentState} - Retrieved state: ${docState} for key: ${key}`);

          // Now, based on the docState, transition to the appropriate state
          if (docState === 'ready') {
            await setRedisKey(redisKey, WORKFLOW_STATES.VALIDATE_OBJECT_S3);
          } else if (docState === 'payment-received') {
            await setRedisKey(redisKey, WORKFLOW_STATES.CONTRACT_REPORT_GPT);
          } else {
            console.error(`${currentState} - Invalid doc state.`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
          }

        } catch (error) {
          console.error(`${currentState} - Error querying Postgres for account ${account} or key ${key}:`, error);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
        }
        break;

      case WORKFLOW_STATES.VALIDATE_OBJECT_S3:
        console.log(`${currentState} - Validating object in S3 for account ${account}, key ${key}`);
        const { allChecksPass, results } = await checkFileAttributes(account, key);
        const resultsJson = JSON.stringify(results);
        await setRedisKey(`contract_metadata_${account}_${key}`, resultsJson);
        console.log(`Stored contract_metadata in Redis: ${resultsJson}`);
        if (!allChecksPass) {
          console.error(`${currentState} - Validation failed for account ${account}, key ${key}`);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
          break;
        }
        await setRedisKey(redisKey, WORKFLOW_STATES.CONTRACT_TEXT_EXTRACTION);
        break;

      case WORKFLOW_STATES.CONTRACT_TEXT_EXTRACTION:
        console.log(`${currentState} - Extracting contract text for account ${account}, key ${key}`);
        const contractText = await extractContractText(account, key);
        if (!contractText) {
          console.error(`${currentState} - Contract text extraction failed for account ${account}, key ${key}`);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
          break;
        }
        await setRedisKey(contractKey, contractText);
        await setRedisKey(redisKey, WORKFLOW_STATES.VALIDATE_CONTENT_PROPS_GPT);
        break;

      case WORKFLOW_STATES.VALIDATE_CONTENT_PROPS_GPT:
        console.log(`${currentState} - Validating content properties using GPT for account ${account}, key ${key}`);
        const validateResult = await validateContractProps(account, key);
        if (!Array.isArray(validateResult) || validateResult.length === 0) {
          console.error(`${currentState} - Validation of content properties failed for account ${account}, key ${key}`);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
          break;
        }

        const validateResultJson = JSON.stringify(validateResult);
        await setRedisKey(`contract_text_props_${account}_${key}`, validateResultJson);
        console.log(`Stored contract_text_props in Redis: ${validateResultJson}`);

        // Retrieve the plan from Redis to determine next state
        const storedPlan = await getRedisKey(`plan_${account}`);
        if (storedPlan === 'pay-per-use') {
          await setRedisKey(redisKey, WORKFLOW_STATES.CONTRACT_TEASER_GPT);
        } else if (storedPlan === 'subscription') {
          await setRedisKey(redisKey, WORKFLOW_STATES.CONTRACT_REPORT_GPT);
        } else {
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
        }
        break;

      case WORKFLOW_STATES.CONTRACT_TEASER_GPT:
        console.log(`${currentState} - Generating contract teaser for account ${account}, key ${key}`);
        const textPropsKey = await getRedisKey(`contract_text_props_${account}_${key}`);
        if (!textPropsKey) {
          console.error(`${currentState} - Contract text props not found for account ${account}, key ${key}`);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
          break;
        }

        try {
          const parsedTextProps = JSON.parse(textPropsKey);
          const { contractTypeCode } = parsedTextProps[0];
          if (!contractTypeCode) {
            console.error(`${currentState} - Contract type code missing for account ${account}, key ${key}`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
            break;
          }

          const contractTeaserText = await getRedisKey(`contract_${account}_${key}`);
          if (!contractTeaserText) {
            console.error(`${currentState} - Contract teaser text not found for account ${account}, key ${key}`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
            break;
          }

          let teaser = await generateTeaser(contractTypeCode, contractTeaserText);
          if (teaser === null) {
            console.error(`${currentState} - Failed to generate teaser for account ${account}, key ${key}`);
            await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
            break;
          }

          // Cleanse teaser JSON before storing it
          teaser = teaser.replace(/^\s*```json\s*/, '').replace(/\s*```$/, '').trim();
          await setRedisKey(`teaser_${account}_${key}`, teaser);
          await setRedisKey(redisKey, WORKFLOW_STATES.COMPLETE);
          console.log(`${currentState} - Successfully generated teaser for account ${account}, key ${key}`);
        } catch (error) {
          console.error(`${currentState} - Error parsing JSON for account ${account}, key ${key}:`, error);
          await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
        }
        break;

      case WORKFLOW_STATES.CONTRACT_REPORT_GPT:
        console.log('starting CONTRACT_REPORT_GPT');
        await setRedisKey(redisKey, WORKFLOW_STATES.COMPLETE);
        break;

      case WORKFLOW_STATES.COMPLETE:
        console.log(`${currentState} - Workflow complete for account ${account}, key ${key}`);
        break;

      case WORKFLOW_STATES.FAILED:
        console.log(`${currentState} - Workflow failed for account ${account}, key ${key}`);
        break;

      default:
        console.log(`${currentState} - Unhandled state for account ${account}, key ${key}`);
    }

    console.log(`${currentState} - Ending workflow for account: ${account}, key: ${key}`);

  } catch (error) {
    console.error(`${currentState} - Error processing state for account ${account}, key ${key}:`, error);
    await setRedisKey(redisKey, WORKFLOW_STATES.FAILED);
  }
};

// Helper functions for extracting contract text, validating props, and generating teasers
const extractContractText = async (account: string, key: string): Promise<string> => {
  const localPDF = `./downloads/pdf/${account}_${key}_1.pdf`;
  const localText = `./downloads/text/${account}_${key}_1.pdf.txt`;
  const bucketName = process.env.S3_BUCKET_NAME || '';
  await downloadS3File(bucketName, `docs/${account}/${key}/1.pdf`, localPDF);
  await pdf2Text(localPDF, localText);
  await uploadS3File(localText, bucketName, `docs/${account}/${key}/1.txt`);
  return await downloadS3TextFileToMemory(bucketName, `docs/${account}/${key}/1.txt`);
};

const validateContractProps = async (account: string, key: string): Promise<Array<any>> => {
  const contractTextProps = await getRedisKey(`contract_${account}_${key}`);
  if (!contractTextProps) return [];

  const prompt = await getPromptValidateContentProps(contractTextProps);
  const gptResult = JSON.parse(await fetchOpenAIResponse(prompt));

  return [{
    isLegible: gptResult.isLegible,
    percentLegible: gptResult.percentLegible,
    isAContract: gptResult.isAContract,
    percentContract: gptResult.percentContract,
    contractTypeCode: gptResult.contractTypeCode,
    language: gptResult.language,
  }];
};

const generateTeaser = async (contractTypeCode: string, contractTeaserText: string | null): Promise<string | null> => {
  if (contractTeaserText === null) {
    console.error('Contract teaser text is null');
    return null;
  }

  const prompt = getPromptTeaser(contractTypeCode, contractTeaserText);
  return await fetchOpenAIResponse(prompt);
};
