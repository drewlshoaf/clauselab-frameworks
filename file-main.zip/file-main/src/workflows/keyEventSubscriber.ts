import { getRedisKey } from '../services/redisService';
import { WORKFLOW_STATES } from './workflowStates';
import { handleStateTransition } from './workflowHandler';
import redisClient from '../services/redisClient';

export const subscribeToKeyEvents = (): void => {
  const subscriber = redisClient.duplicate();

  subscriber.psubscribe('__keyspace@0__:*');

  subscriber.on('pmessage', async (pattern: string, channel: string, message: string): Promise<void> => {
    const redisKey = channel.split(':')[1];
    if (!redisKey.startsWith('state_')) return;

    const redisKeyParts = redisKey.split('_');
    const account = redisKeyParts[1];
    const key = redisKeyParts[2];

    if (message === 'set') {
      const currentState = await getRedisKey(redisKey);
      if (currentState) {
        handleStateTransition(currentState as WORKFLOW_STATES, { account, key, redisKey });
      }
    }
  });
};
