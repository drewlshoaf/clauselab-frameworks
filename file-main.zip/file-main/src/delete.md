delete
aws s3 rm s3://clauselab/docs/accountdrew/39/ --recursive


create w/ file
aws s3 cp ./1.pdf s3://clauselab/docs/accountdrew/40/1.pdf