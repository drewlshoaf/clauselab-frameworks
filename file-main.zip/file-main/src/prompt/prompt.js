import metadataRESLEASE1 from './metadata/RESLEASE1.js';
import metadataEMPAGRMT1 from './metadata/EMPAGRMT1.js';

const processMetadata = (metadata) => {
  return Object.entries(metadata).map(([section, details]) => {
    return {
      section,
      details: details.map(item => {
        const key = Object.keys(item)[0];
        return { [key]: item[key] };
      })
    };
  });
};

const getPrompt = (doctype, roletype, document) => {
  let metadataCategories;
  let docname;

  switch (doctype) {
    case "RESLEASE1":
      docname = "Residential Lease Agreement";
      metadataCategories = metadataRESLEASE1;
      break;
    case "EMPAGRMT1":
      docname = "Employment Agreement";
      metadataCategories = metadataEMPAGRMT1;
      break;
    default:
      throw new Error(`Unsupported document type: ${doctype}`);
  }

  const processedMetadata = processMetadata(metadataCategories);

  return `
Pretend you're an advisor to the ${roletype} entering into a ${docname}.
Identify the general risks to the ${roletype} in the below ${docname}.
For each risk, you should provide a title, a detailed description of the risk including its potential 
impact on the ${roletype}, and comprehensive actions the ${roletype} can take to mitigate the risk. 
Classify each risk as low, medium, or high.
Additionally, extract key metadata from the contract and provide it in a table format with the 
following categories and their details:

${processedMetadata.map(category => `
${category.section}
${category.details.map(item => `- ${Object.keys(item)[0]}: ${Object.values(item)[0]}`).join('\n')}
`).join('\n')}

If any of the components above do not exist in the contract, identify this as one of the risks, providing a 
title, detailed description of the risk, its potential impact on the ${roletype}, classification 
(low, medium, or high), and comprehensive remediation actions.

Aim to identify at least 15 risks, if reasonably possible.

Include an executive summary (property "summary") that summarizes the overall agreement and highlights 
the overall level of risks, as well as any high risks.

Return a JSON document like this:

{
  "summary": "",
  "metadata": ${JSON.stringify(processedMetadata)},
  "risks": [
    {
      "title": "",
      "description": "",
      "classification": "",
      "remediation": [
        ""
      ]
    }
  ]
}
Only return the JSON response. Do not return any additional information, or context, or acknowledgement.

Here is the ${docname}: ${document}
  `;
};

export { getPrompt };
