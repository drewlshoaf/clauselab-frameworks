import { promptResidentialLeaseAgreement } from './Residential-Lease-Agreement.js';

export const getPromptTeaser = (contractTypeCode: string, contractText: string) => {
    switch (contractTypeCode) {
      case "Residential-Lease-Agreement":
        return promptResidentialLeaseAgreement(contractText)
      default:
        throw new Error(`Unsupported contractText type: ${contractTypeCode}`);
    }
};

