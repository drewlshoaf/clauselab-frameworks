// checkFileType.ts
import { S3Client, GetObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { Readable } from 'stream';

export async function checkFileType(bucketName: string, s3ObjectPath: string): Promise<boolean> {
  const s3 = new S3Client({ region: process.env.AWS_REGION });

  try {
    // Step 1: Fetch metadata from S3
    const headCommand = new HeadObjectCommand({
      Bucket: bucketName,
      Key: s3ObjectPath,
    });

    const metadata = await s3.send(headCommand);
    
    // Check if the ContentType is 'application/pdf'
    const isContentTypePDF = metadata.ContentType === 'application/pdf';
    
    // Step 2: Fetch the first few bytes (magic number)
    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: s3ObjectPath,
      Range: 'bytes=0-4',  // Fetch first 5 bytes
    });

    const response = await s3.send(command);
    
    // Read the first few bytes of the file
    const stream = response.Body as Readable;
    const chunks = [];
    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const fileHeader = Buffer.concat(chunks).toString();
    
    // Check if the magic number matches PDF (%PDF)
    const isMagicNumberPDF = fileHeader.startsWith('%PDF');

    // Return true if both the metadata and magic number indicate it's a PDF
    return isContentTypePDF && isMagicNumberPDF;

  } catch (error) {
    console.error('Error in checkFileType:', error);
    return false;  // In case of an error, assume it's not a PDF
  }
}

