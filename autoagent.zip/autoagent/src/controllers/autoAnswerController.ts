import { Request, Response } from 'express';
import redis from '../config/redis';
import { checkNegotiationExists } from '../services/autoAnswerService';

export async function createAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  try {
    const negotiationExists = await checkNegotiationExists(negotiation_id, party_id);
    if (!negotiationExists) {
      return res.status(404).json({ error: 'Negotiation ID and Party ID combination not found' });
    }

    const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    await redis.set(redisKey, currentTimestamp);

    res.status(200).json({ message: 'Auto Answer Initialized', negotiation_id, party_id });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to initialize Auto Answer' });
  }
}

export async function updateAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;
  const updatedTimestamp = Math.floor(Date.now() / 1000);

  try {
    const exists = await redis.exists(redisKey);
    if (!exists) {
      return res.status(404).json({ error: 'Auto Answer key does not exist' });
    }

    await redis.set(redisKey, updatedTimestamp);
    res.status(200).json({ message: 'Auto Answer Updated', negotiation_id, party_id });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to update Auto Answer' });
  }
}

export async function deleteAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;

  try {
    const result = await redis.del(redisKey);
    if (result === 0) {
      return res.status(404).json({ error: 'Auto Answer key does not exist' });
    }

    res.status(200).json({ message: 'Auto Answer Deleted', negotiation_id, party_id });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to delete Auto Answer' });
  }
}

export async function getAllAutoAnswers(req: Request, res: Response): Promise<void> {
  try {
    const keys = await redis.keys('AutoAnswer_*');
    const keyValues: Record<string, string | null> = {};

    for (const key of keys) {
      const value = await redis.get(key);
      keyValues[key] = value;
    }

    res.status(200).json({ data: keyValues });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to retrieve Auto Answer keys and values' });
  }
}

