import { Request, Response } from 'express';
import Redis from 'ioredis';
import mongoose from 'mongoose';
import Negotiation from '../models/Negotiation';

const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379', 10),
});

const mongoURI = process.env.MONGO_URI || 'mongodb://mongo:27017/mydatabase';

mongoose.connect(mongoURI, {
  serverSelectionTimeoutMS: 30000, // Timeout after 30s instead of 10s
  socketTimeoutMS: 45000 // Close sockets after 45s of inactivity
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

export async function createAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  // Check if the negotiation and party combination exists in MongoDB
  try {
    const negotiation = await Negotiation.findOne({
      negotiation_id: negotiation_id,
      parties: { $elemMatch: { party_id: party_id } }
    });

    if (!negotiation) {
      return res.status(404).json({ error: 'Negotiation ID and Party ID combination not found' });
    }
  } catch (error) {
    console.error('MongoDB error:', error);
    return res.status(500).json({ error: 'Database query failed' });
  }

  const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;
  const currentTimestamp = Math.floor(Date.now() / 1000); // Epoch timestamp in seconds

  try {
    // Set Redis key with the timestamp value
    await redis.set(redisKey, currentTimestamp);
    const result = await redis.get(redisKey);
    console.log('result', result);

    res.status(200).json({ message: 'Auto Answer Initialized', negotiation_id, party_id });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to initialize Auto Answer', negotiation_id, party_id });
  }
}
export async function updateAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;
  const updatedTimestamp = Math.floor(Date.now() / 1000); // Epoch timestamp in seconds

  try {
    // Check if the key exists
    const exists = await redis.exists(redisKey);
    if (!exists) {
      return res.status(404).json({ error: 'Auto Answer key does not exist' });
    }

    // Update the Redis key with the new timestamp
    await redis.set(redisKey, updatedTimestamp);

    res.status(200).json({ message: 'Auto Answer Updated', negotiation_id, party_id });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to update Auto Answer', negotiation_id, party_id });
  }
}

export async function deleteAutoAnswer(req: Request, res: Response) {
  const { negotiation_id, party_id } = req.body;

  if (!negotiation_id || !party_id) {
    return res.status(400).json({ error: 'Negotiation ID and Party ID are required' });
  }

  const redisKey = `AutoAnswer_${negotiation_id}_${party_id}`;

  try {
    // Delete the Redis key
    const result = await redis.del(redisKey);
    
    if (result === 0) {
      return res.status(404).json({ error: 'Auto Answer key does not exist' });
    }

    res.status(200).json({ message: 'Auto Answer Deleted', negotiation_id, party_id });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to delete Auto Answer', negotiation_id, party_id });
  }
}

export async function getAllAutoAnswers(req: Request, res: Response): Promise<void> {
  try {
    // Fetch all keys that start with "AutoAnswer_"
    const keys = await redis.keys('AutoAnswer_*');
    const keyValues: Record<string, string | null> = {};

    // Fetch values for each key and store in the keyValues object
    for (const key of keys) {
      const value = await redis.get(key);
      keyValues[key] = value;
    }

    res.status(200).json({ data: keyValues });
  } catch (error) {
    console.error('Redis error:', error);
    res.status(500).json({ error: 'Failed to retrieve Auto Answer keys and values' });
  }
}
