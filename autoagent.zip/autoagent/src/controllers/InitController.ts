import { Request, Response } from 'express';
import { storyMakerQueue } from '../queues/MakeAutoAgentInitQueue';

export async function InitController(req: Request, res: Response) {
  const { negotiation_id, negotiation_type, parties } = req.body;

  try {
    await storyMakerQueue.add('Initializing AutoAgent workflow', {
      negotiation_id: negotiation_id,  
    });
    res.status(200).json({ message: 'New AutoAgent Flow Initialized', negotiation_id });
  } catch (error) {
    res.status(500).json({ error: 'Failed to initialize AutoAgent' });
  }
}

