import mongoose, { Schema, Document } from 'mongoose';

const QuestionSchema = new Schema({
  question_id: { type: String, required: true },
  question_text: { type: String, required: true },
  answer: { type: String, required: false }, // Define answer as optional
});

const PartySchema = new Schema({
  name: { type: String, required: true },
  party_id: { type: String, required: true },
  role: { type: String, required: true },
  story: { type: String, required: true },
  questions: { type: [QuestionSchema], default: [] },
});

const NegotiationSchema = new Schema(
  {
    negotiation_id: { type: String, required: true, unique: true },
    negotiation_type: { type: String, required: true },
    parties: { type: [PartySchema], required: true },
  },
  { timestamps: true }
);

export interface INegotiation extends Document {
  negotiation_id: string;
  negotiation_type: string;
  parties: {
    name: string;
    party_id: string;
    role: string;
    story: string;
    questions: {
      question_id: string;
      question_text: string;
      answer?: string; // Optional answer property in TypeScript interface
    }[];
  }[];
}

const Negotiation = mongoose.model<INegotiation>('Negotiation', NegotiationSchema);

export default Negotiation;
