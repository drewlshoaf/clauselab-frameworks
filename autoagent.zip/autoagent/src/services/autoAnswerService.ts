import Negotiation from '../models/Negotiation';

export async function checkNegotiationExists(negotiation_id: string, party_id: string): Promise<boolean> {
  try {
    const negotiation = await Negotiation.findOne({
      negotiation_id,
      parties: { $elemMatch: { party_id } }
    });
    return !!negotiation;
  } catch (error) {
    console.error('MongoDB error:', error);
    throw new Error('Database query failed');
  }
}

