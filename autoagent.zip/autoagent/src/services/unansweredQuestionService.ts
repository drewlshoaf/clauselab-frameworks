import { Queue } from 'bullmq';
import Negotiation from '../models/Negotiation';
import redis from '../config/redis';

// Setup BullMQ Queue for Answer Maker
const answerMakerQueue = new Queue('answerMakerQueue', { connection: redis });

// Function to check for unanswered questions in MongoDB
async function checkForUnansweredQuestions() {
  console.log('------------------running checkForUnansweredQuestions------------------')
  try {
    // Find all negotiations with parties containing questions without an "answer" field
    const negotiations = await Negotiation.find({
      parties: {
        $elemMatch: {
          questions: {
            $elemMatch: {
              question_text: { $exists: true },
              answer: { $exists: false },
            },
          },
        },
      },
    });

    for (const negotiation of negotiations) {
      for (const party of negotiation.parties) {
        for (const question of party.questions) {
          if (question.question_text && !question.answer) {
            // Add a message to the answerMakerQueue for each unanswered question
            await answerMakerQueue.add('answer-job', {
              negotiation_id: negotiation.negotiation_id,
              party_id: party.party_id,
              question_id: question.question_id,
              question_text: question.question_text,
            });
            console.log(`Added question ${question.question_id} to answerMakerQueue`);
          }
        }
      }
    }
  } catch (error) {
    console.error('Error querying MongoDB for unanswered questions:', error);
  }
}

// Function to initialize the interval for checking unanswered questions
export function startUnansweredQuestionService() {
  // Run the checkForUnansweredQuestions function every 10 seconds
  setInterval(checkForUnansweredQuestions, 10000);
}
