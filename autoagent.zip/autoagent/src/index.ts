import mongoose from 'mongoose';
import express from 'express';
import connectToMongo from './config/mongo';
import { startUnansweredQuestionService } from './services/unansweredQuestionService';
import * as autoAnswerController from './controllers/autoAnswerController';

const app = express();
const PORT = process.env.AUTOAGENT_PORT || 3001;

app.use(express.json());

// Express routes
app.post('/autoanswer', autoAnswerController.createAutoAnswer);
app.put('/autoanswer', autoAnswerController.updateAutoAnswer);
app.delete('/autoanswer', autoAnswerController.deleteAutoAnswer);
app.get('/autoanswer', autoAnswerController.getAllAutoAnswers);

async function startServer() {
  await connectToMongo();

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  // Start the unanswered question service
  startUnansweredQuestionService();
}

startServer().catch((error) => {
  console.error('Failed to start the application:', error);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await mongoose.disconnect();
  // redis.quit();
  console.log('Service shutdown complete');
  process.exit(0);
});

