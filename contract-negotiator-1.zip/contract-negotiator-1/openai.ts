import OpenAI from 'openai';

// Define the type for OpenAI response message
interface OpenAIMessage {
  role: string;
  content: string | null;  // Allow null for content
}

// Define the type for OpenAI response choices
interface OpenAIChoice {
  message: OpenAIMessage;
}

// Define the type for the OpenAI API response
interface OpenAIResponse {
  choices: OpenAIChoice[];
}

// Configure OpenAI client with the API key from environment variables
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY as string,  // Use your API key from environment variables
});

/**
 * Fetches a response from OpenAI's chat model and ensures that the response is clean, valid JSON.
 * 
 * @param {string} prompt - The prompt to send to the OpenAI API.
 * @returns {Promise<object>} - A parsed JSON object response from the API.
 */
export const fetchOpenAIResponse = async (prompt: string): Promise<object> => {
  const responses: string[] = [];
  let done = false;
  let retryCount = 0;

  // Configuration variables from environment
  const maxRetries = parseInt(process.env.MAX_RETRIES || '3');
  const maxTokens = parseInt(process.env.MAX_TOKENS || '1500');
  const model = process.env.OPENAI_MODEL || 'gpt-4o-2024-08-06';

  while (!done && retryCount < maxRetries) {
    try {
      const openaiResponse = await openai.chat.completions.create({
        model: model,
        messages: [{
          role: 'user',
          content: prompt,
        }],
        max_tokens: maxTokens,
      });

      // Extract the content and add it to responses
      const gptResponse = openaiResponse.choices[0]?.message.content?.trim() || '';
      responses.push(gptResponse);

      // Check if this is the final response part
      if (gptResponse.endsWith('```')) {
        done = true;
      } else if (gptResponse.length >= maxTokens) {
        retryCount++;
      } else {
        done = true;
      }
    } catch (error: any) {
      // If an authentication error occurs, do not retry
      if (error.status === 401 || error.code === 'AuthenticationError') {
        throw new Error('Authentication failed. Check your API key.');
      }

      retryCount++;
      if (retryCount >= maxRetries) {
        throw new Error('Max retries reached.');
      }
    }
  }

  // Combine all parts of the response and clean it up
  const rawResponse = responses.join(' ').trim();

  // Ensure valid JSON structure
  const possibleJSON = extractJSON(rawResponse);

  try {
    return JSON.parse(possibleJSON);
  } catch (err) {
    console.error('Error parsing OpenAI response as JSON:', err);
    console.log('Raw cleaned response:', possibleJSON);  // Debugging info: log the cleaned response
    throw new Error('Invalid JSON format received from OpenAI.');
  }
};

/**
 * Function to extract a valid JSON block from a potentially malformed response.
 */
const extractJSON = (response: string): string => {
  // Use a regex to locate the first valid JSON block
  const jsonMatch = response.match(/{[\s\S]*}/);
  if (jsonMatch) {
    return jsonMatch[0]
      .replace(/\\n/g, '')  // Remove line breaks
      .replace(/\s{2,}/g, ' ')  // Replace multiple spaces
      .trim();
  }
  throw new Error('No valid JSON found in response.');
};
