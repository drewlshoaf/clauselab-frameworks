
import dotenv from 'dotenv'; // Load dotenv to handle environment variables
dotenv.config(); // This will load the .env file
import OpenAI from 'openai';
import { z } from 'zod';
import fs from 'fs';
import path from 'path';
import { zodResponseFormat } from 'openai/helpers/zod';

// Define Zod schema for the structured output
const ContractSchema = z.object({
  title: z.string(),
  parties: z.array(z.object({
    name: z.string(),
    role: z.string(),
  })),
  effectiveDate: z.string(),
  clauses: z.array(z.object({
    clauseNumber: z.number(),
    title: z.string(),
    description: z.string(),
  })),
  termination: z.string().optional(),
});

// Initialize OpenAI API
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Helper function to read contract.txt
function readContractFile(): Promise<string> {
  const filePath = path.resolve(__dirname, 'contract.txt');
  return new Promise((resolve, reject) => {
    fs.readFile(filePath, 'utf-8', (err, data) => {
      if (err) {
        reject(new Error('Contract file not found'));
      } else {
        resolve(data);
      }
    });
  });
}

// Function to generate a structured prompt and request structured output
async function generateContractTeaser(contractText: string): Promise<any> {
  const prompt = `Analyze the following contract and provide a structured summary. Adhere to the schema: title, parties, effective date, clauses, and termination. Here is the contract: ${contractText}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
    response_format: zodResponseFormat(ContractSchema, 'ContractSchema'), // Provide name here
  });

  // Extract the content of the message (as string)
  const output = response.choices[0]?.message?.content;

  try {
    // Parse the JSON content using Zod
    const parsedOutput = ContractSchema.parse(JSON.parse(output || '{}'));
    return parsedOutput;
  } catch (err) {
    console.error('Failed to parse response:', err);
    throw err;
  }
}

// Main function to execute the flow
async function main() {
  try {
    // Step 1: Read contract file
    const contractText = await readContractFile();

    // Step 2: Send contract text to ChatGPT and get structured output
    const structuredOutput = await generateContractTeaser(contractText);

    // Step 3: Write structured output to a local file (output.json)
    const outputFilePath = path.resolve(__dirname, 'output.json');
    fs.writeFileSync(outputFilePath, JSON.stringify(structuredOutput, null, 2));
    console.log(`Structured output written to ${outputFilePath}`);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Run the main function
main();