"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zodResponseFormat = void 0;
/**
 * zodResponseFormat is a utility function to format Zod schemas into a format
 * that OpenAI's API can understand and use for structured responses.
 *
 * @param {ZodSchema} schema - The Zod schema that defines the structure of the response.
 * @param {string} label - A label to identify the schema type in the request.
 * @returns {ResponseFormatOptions} - The formatted response structure for the OpenAI request.
 */
const zodResponseFormat = (schema, label) => {
    return {
        schema,
        label,
    };
};
exports.zodResponseFormat = zodResponseFormat;
