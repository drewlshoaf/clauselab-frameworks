import OpenAI from 'openai';
import { z, ZodSchema } from 'zod';
import { zodResponseFormat } from './helper/zodhelper';

// Example: Define Zod schema for a contract as a flexible structure
const ContractSchema = z.object({
  title: z.string(),
  parties: z.array(z.object({
    name: z.string(),
    role: z.string(),
  })),
  effectiveDate: z.string(),
  clauses: z.array(z.object({
    clauseNumber: z.number(),
    title: z.string(),
    description: z.string(),
  })),
  termination: z.string().optional(),
});

// Define the type for OpenAI response message
interface OpenAIMessage {
  role: string;
  content: string | null;  // Allow null for content
}

// Define the type for OpenAI response choices
interface OpenAIChoice {
  message: OpenAIMessage;
}

// Define the type for the OpenAI API response
interface OpenAIResponse {
  choices: OpenAIChoice[];
}

// Configure OpenAI client with the API key from environment variables
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY as string,  // Use your API key from environment variables
});

/**
 * Fetches a response from OpenAI's chat model and ensures that the response matches a given format.
 * 
 * @param {string} prompt - The prompt to send to the OpenAI API.
 * @param {ZodSchema} response_format - Zod schema for validating the structure of the response.
 * @returns {Promise<object>} - A parsed and validated JSON object response from the API.
 */
export const fetchOpenAIResponse = async (prompt: string, response_format: ZodSchema): Promise<object> => {
  const responses: string[] = [];
  let done = false;
  let retryCount = 0;

  // Configuration variables from environment
  const maxRetries = parseInt(process.env.MAX_RETRIES || '3');
  const maxTokens = parseInt(process.env.MAX_TOKENS || '1500');
  const model = process.env.OPENAI_MODEL || 'gpt-4o-2024-08-06';

  while (!done && retryCount < maxRetries) {
    try {
      const openaiResponse = await openai.beta.chat.completions.parse({
        model: model,
        messages: [{
          role: 'user',
          content: prompt,
        }],
        response_format: zodResponseFormat(response_format, "parsed_response"), // Using response format directly in request
        max_tokens: maxTokens,
      });

      // Extract the parsed response and add it to responses
      const gptResponse = openaiResponse.choices[0]?.message.content?.trim() || '';
      responses.push(gptResponse);

      // Check if this is the final response part
      if (gptResponse.endsWith('```')) {
        done = true;
      } else if (gptResponse.length >= maxTokens) {
        retryCount++;
      } else {
        done = true;
      }
    } catch (error: any) {
      // If an authentication error occurs, do not retry
      if (error.status === 401 || error.code === 'AuthenticationError') {
        throw new Error('Authentication failed. Check your API key.');
      }

      retryCount++;
      if (retryCount >= maxRetries) {
        throw new Error('Max retries reached.');
      }
    }
  }

  // Combine all parts of the response and clean it up
  const rawResponse = responses.join(' ').trim();

  try {
    // The response should already be validated against the Zod schema by OpenAI
    return JSON.parse(rawResponse);
  } catch (err) {
    console.error('Error parsing OpenAI response as JSON:', err);
    console.log('Raw cleaned response:', rawResponse);  // Debugging info: log the cleaned response
    throw new Error('Invalid JSON format received from OpenAI.');
  }
};
