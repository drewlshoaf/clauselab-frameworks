"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv")); // Load dotenv to handle environment variables
dotenv_1.default.config(); // This will load the .env file
const openai_1 = __importDefault(require("openai"));
const zod_1 = require("zod");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const zod_2 = require("openai/helpers/zod");
// Define Zod schema for the structured output
const ContractSchema = zod_1.z.object({
    title: zod_1.z.string(),
    parties: zod_1.z.array(zod_1.z.object({
        name: zod_1.z.string(),
        role: zod_1.z.string(),
    })),
    effectiveDate: zod_1.z.string(),
    clauses: zod_1.z.array(zod_1.z.object({
        clauseNumber: zod_1.z.number(),
        title: zod_1.z.string(),
        description: zod_1.z.string(),
    })),
    termination: zod_1.z.string().optional(),
});
// Initialize OpenAI API
const openai = new openai_1.default({
    apiKey: process.env.OPENAI_API_KEY,
});
// Helper function to read contract.txt
function readContractFile() {
    const filePath = path_1.default.resolve(__dirname, 'contract.txt');
    return new Promise((resolve, reject) => {
        fs_1.default.readFile(filePath, 'utf-8', (err, data) => {
            if (err) {
                reject(new Error('Contract file not found'));
            }
            else {
                resolve(data);
            }
        });
    });
}
// Function to generate a structured prompt and request structured output
function generateContractTeaser(contractText) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const prompt = `Analyze the following contract and provide a structured summary. Adhere to the schema: title, parties, effective date, clauses, and termination. Here is the contract: ${contractText}`;
        const response = yield openai.chat.completions.create({
            model: 'gpt-4',
            messages: [{ role: 'user', content: prompt }],
            response_format: (0, zod_2.zodResponseFormat)(ContractSchema, 'ContractSchema'), // Provide name here
        });
        // Extract the content of the message (as string)
        const output = (_b = (_a = response.choices[0]) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b.content;
        try {
            // Parse the JSON content using Zod
            const parsedOutput = ContractSchema.parse(JSON.parse(output || '{}'));
            return parsedOutput;
        }
        catch (err) {
            console.error('Failed to parse response:', err);
            throw err;
        }
    });
}
// Main function to execute the flow
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Step 1: Read contract file
            const contractText = yield readContractFile();
            // Step 2: Send contract text to ChatGPT and get structured output
            const structuredOutput = yield generateContractTeaser(contractText);
            // Step 3: Write structured output to a local file (output.json)
            const outputFilePath = path_1.default.resolve(__dirname, 'output.json');
            fs_1.default.writeFileSync(outputFilePath, JSON.stringify(structuredOutput, null, 2));
            console.log(`Structured output written to ${outputFilePath}`);
        }
        catch (error) {
            console.error('Error:', error);
        }
    });
}
// Run the main function
main();
