"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.metadata = void 0;
exports.metadata = {
    "Introduction": [
        {
            machine_name: "title",
            friendly_name: "Title",
            description: "The title of the document, e.g., Residential Lease Agreement",
        },
        {
            machine_name: "date",
            friendly_name: "Date",
            description: "The date when the agreement is made",
        },
    ],
    "Parties": [
        {
            machine_name: "landlord_name",
            friendly_name: "Landlord Name",
            description: "Name of the landlord",
        },
        {
            machine_name: "tenant_names",
            friendly_name: "Tenant Names",
            description: "Names of the tenant(s)",
        },
    ],
    "Premises": [
        {
            machine_name: "property_address",
            friendly_name: "Property Address",
            description: "Full address, including unit number or specific property description",
        },
        {
            machine_name: "type_of_property",
            friendly_name: "Type of Property",
            description: "Type of property (e.g., apartment, single-family home)",
        },
        {
            machine_name: "storage_provided",
            friendly_name: "Storage Provided",
            description: "Whether storage space is provided as part of the lease",
        },
        {
            machine_name: "common_area_access",
            friendly_name: "Common Areas Access",
            description: "Access to shared areas like gyms, pools, or laundry rooms",
        },
        {
            machine_name: "common_area_rules",
            friendly_name: "Common Area Rules",
            description: "Guidelines for using common areas",
        },
    ],
    "Term of Lease": [
        {
            machine_name: "start_date",
            friendly_name: "Start Date",
            description: "When the lease begins",
        },
        {
            machine_name: "end_date",
            friendly_name: "End Date",
            description: "When the lease ends",
        },
        {
            machine_name: "renewal_terms",
            friendly_name: "Renewal Terms",
            description: "Conditions for renewal or extension of the lease",
        },
    ],
    "Rent": [
        {
            machine_name: "rent_amount",
            friendly_name: "Rent Amount",
            description: "Monthly rent amount",
        },
        {
            machine_name: "due_date",
            friendly_name: "Rent Due Date",
            description: "When rent is due (e.g., first day of each month)",
        },
        {
            machine_name: "payment_method",
            friendly_name: "Payment Method",
            description: "Accepted forms of payment (e.g., check, online transfer)",
        },
        {
            machine_name: "late_fees",
            friendly_name: "Late Fees",
            description: "Penalties for late payment, including amount and when they apply",
        },
        {
            machine_name: "rent_increase_limit",
            friendly_name: "Rent Increase Cap",
            description: "Maximum allowable percentage for rent increase",
        },
    ],
    "Security Deposit": [
        {
            machine_name: "security_deposit_amount",
            friendly_name: "Security Deposit Amount",
            description: "Amount of the security deposit",
        },
        {
            machine_name: "conditions_for_return",
            friendly_name: "Conditions for Return",
            description: "Terms under which the deposit will be returned or withheld",
        },
        {
            machine_name: "security_deposit_interest",
            friendly_name: "Security Deposit Interest",
            description: "Whether interest is paid on the security deposit",
        },
        {
            machine_name: "security_deposit_deductions",
            friendly_name: "Security Deposit Deductions",
            description: "Detailed breakdown of potential deductions.",
        },
    ],
    "Utilities and Services": [
        {
            machine_name: "utility_responsibility",
            friendly_name: "Responsibility for Utilities",
            description: "Who is responsible for paying utilities",
        },
        {
            machine_name: "included_services",
            friendly_name: "Included Services",
            description: "Services included in the rent (e.g., trash removal, lawn care)",
        },
        {
            machine_name: "trash_collection",
            friendly_name: "Trash Collection",
            description: "Details about trash collection (days, locations)",
        },
        {
            machine_name: "recycling_collection",
            friendly_name: "Recycling Collection",
            description: "Information on recycling services",
        },
        {
            machine_name: "utility_submetering",
            friendly_name: "Utility Submetering",
            description: "Details on how utilities (e.g., water, gas) are submetered",
        },
    ],
    "Maintenance and Repairs": [
        {
            machine_name: "landlord_responsibilities",
            friendly_name: "Landlord Responsibilities",
            description: "What the landlord is responsible for maintaining and repairing",
        },
        {
            machine_name: "tenant_responsibilities",
            friendly_name: "Tenant Responsibilities",
            description: "What the tenant is responsible for maintaining and repairing",
        },
        {
            machine_name: "reporting_issues",
            friendly_name: "Reporting Issues",
            description: "How and when the tenant should report maintenance issues",
        },
        {
            machine_name: "landscaping_responsibility",
            friendly_name: "Landscaping Responsibility",
            description: "Who is responsible for maintaining the yard or landscaping",
        },
        {
            machine_name: "pest_control_responsibility",
            friendly_name: "Pest Control Responsibility",
            description: "Who is responsible for pest control services",
        },
        {
            machine_name: "fire_safety_smoke_detectors",
            friendly_name: "Smoke Detectors",
            description: "Location and maintenance of smoke detectors",
        },
        {
            machine_name: "damage_reporting",
            friendly_name: "Damage Reporting",
            description: "Procedures and timeline for reporting damages",
        },
        {
            machine_name: "lock_change_policy",
            friendly_name: "Lock Change Policy",
            description: "Procedures for changing locks during the lease term",
        },
        {
            machine_name: "key_replacement_policy",
            friendly_name: "Key Replacement Policy",
            description: "Procedures and fees for lost or replacement keys.",
        },
        {
            machine_name: "move_in_condition_report",
            friendly_name: "Move-In Condition Report",
            description: "Initial condition of the property at move-in.",
        },
        {
            machine_name: "move_out_procedures",
            friendly_name: "Move-Out Procedures",
            description: "Steps for vacating the property, including cleaning and inspection.",
        },
    ],
    "Use of Premises": [
        {
            machine_name: "permitted_use",
            friendly_name: "Permitted Use",
            description: "Residential use only, any restrictions on use",
        },
        {
            machine_name: "prohibited_activities",
            friendly_name: "Prohibited Activities",
            description: "Activities that are not allowed (e.g., illegal activities, commercial use)",
        },
        {
            machine_name: "noise_restrictions",
            friendly_name: "Noise Restrictions",
            description: "Quiet hours or noise level regulations",
        },
        {
            machine_name: "noise_complaint_procedures",
            friendly_name: "Noise Complaint Procedures",
            description: "Process for handling noise complaints.",
        },
        {
            machine_name: "smoke_free_policy",
            friendly_name: "Smoke-Free Policy",
            description: "Whether the property is designated as smoke-free.",
        },
        {
            machine_name: "grill_permissions",
            friendly_name: "Grill Permissions",
            description: "Whether tenants can use grills (e.g., propane or charcoal)",
        },
        {
            machine_name: "balcony_use",
            friendly_name: "Balcony Use",
            description: "Rules for using balconies or decks",
        },
        {
            machine_name: "hoa_rules",
            friendly_name: "HOA Rules",
            description: "Rules established by a homeowners association",
        },
    ],
    "Occupants": [
        {
            machine_name: "authorized_tenants",
            friendly_name: "Authorized Tenants",
            description: "Names of all individuals authorized to live on the premises",
        },
        {
            machine_name: "guest_policy",
            friendly_name: "Guest Policy",
            description: "Rules regarding guests, including duration of stay",
        },
    ],
    "Furnishings and Appliances": [
        {
            machine_name: "provided_items",
            friendly_name: "Provided Items",
            description: "List of furnishings and appliances provided by the landlord",
        },
        {
            machine_name: "condition_of_items",
            friendly_name: "Condition of Provided Items",
            description: "Condition of provided items at the start of the lease",
        },
        {
            machine_name: "window_coverings",
            friendly_name: "Window Coverings",
            description: "Any blinds or curtains provided by the landlord",
        },
    ],
    "Pet Policy": [
        {
            machine_name: "pet_permission",
            friendly_name: "Pet Permission",
            description: "Whether pets are allowed",
        },
        {
            machine_name: "pet_restrictions",
            friendly_name: "Pet Restrictions",
            description: "Types and number of pets allowed",
        },
        {
            machine_name: "pet_fees",
            friendly_name: "Pet Fees and Deposits",
            description: "Any additional fees or deposits required for pets",
        },
    ],
    "Insurance": [
        {
            machine_name: "tenant_insurance",
            friendly_name: "Tenant Insurance",
            description: "Requirement for tenant to have renter's insurance",
        },
        {
            machine_name: "landlord_insurance",
            friendly_name: "Landlord Insurance",
            description: "Landlord's insurance responsibilities",
        },
        {
            machine_name: "flood_insurance",
            friendly_name: "Flood Insurance",
            description: "Whether tenants must carry flood insurance",
        },
        {
            machine_name: "acts_of_god_liability",
            friendly_name: "Acts of God Liability",
            description: "Who is responsible for damages from natural disasters",
        },
    ],
    "Alterations and Improvements": [
        {
            machine_name: "alteration_permission",
            friendly_name: "Permission for Alterations",
            description: "Requirement for tenant to get written consent before making alterations",
        },
    ],
    "Entry by Landlord": [
        {
            machine_name: "landlord_entry_notice",
            friendly_name: "Notice for Landlord Entry",
            description: "Amount of notice the landlord must give before entering the premises",
        },
    ],
    "Subleasing and Assignment": [
        {
            machine_name: "subleasing_permission",
            friendly_name: "Permission for Subleasing",
            description: "Whether subleasing is allowed",
        },
    ],
    "Default and Termination": [
        {
            machine_name: "tenant_default_conditions",
            friendly_name: "Default Conditions",
            description: "Conditions that constitute a default by the tenant",
        },
        {
            machine_name: "landlord_remedies",
            friendly_name: "Landlord Remedies for Tenant Default",
            description: "Landlord's remedies in case of tenant default",
        },
        {
            machine_name: "early_termination_tenant",
            friendly_name: "Early Termination by Tenant",
            description: "Conditions under which the tenant can terminate the lease early",
        },
        {
            machine_name: "early_termination_both",
            friendly_name: "Early Termination by Both Parties",
            description: "Conditions under which both parties can terminate the lease early",
        },
        {
            machine_name: "eviction_procedures",
            friendly_name: "Eviction Procedures",
            description: "The legal process for eviction in case of default",
        },
    ],
    "Military Clause": [
        {
            machine_name: "military_clause_termination",
            friendly_name: "Military Clause Termination",
            description: "Rights of military personnel to terminate the lease early due to relocation or deployment",
        },
    ],
    "Dispute Resolution": [
        {
            machine_name: "mediation_arbitration",
            friendly_name: "Mediation/Arbitration",
            description: "Methods for resolving disputes between landlord and tenant",
        },
        {
            machine_name: "legal_fees_responsibility",
            friendly_name: "Legal Fees Responsibility",
            description: "Responsibility for legal fees in case of a dispute",
        },
    ],
    "Notices": [
        {
            machine_name: "notices_addresses",
            friendly_name: "Addresses for Notices",
            description: "Addresses where notices should be sent for both landlord and tenant",
        },
        {
            machine_name: "notices_method",
            friendly_name: "Method of Notice Delivery",
            description: "Accepted methods for delivering notices (e.g., mail, email)",
        },
    ],
    "Jurisdiction": [
        {
            machine_name: "jurisdiction",
            friendly_name: "Jurisdiction",
            description: "Legal jurisdiction governing the lease",
        },
        {
            machine_name: "jurisdictions_country",
            friendly_name: "Country",
            description: "The country where the agreement is applicable",
        },
        {
            machine_name: "jurisdictions_state_province",
            friendly_name: "State/Province",
            description: "The state or province where the agreement is applicable",
        },
        {
            machine_name: "jurisdictions_city",
            friendly_name: "City",
            description: "The city where the agreement is applicable",
        },
    ],
    "Parking": [
        {
            machine_name: "parking_availability",
            friendly_name: "Parking Availability",
            description: "Whether parking is provided",
        },
        {
            machine_name: "parking_fees",
            friendly_name: "Parking Fees",
            description: "Any additional fees for parking",
        },
        {
            machine_name: "parking_space_assignment",
            friendly_name: "Parking Space Assignment",
            description: "Specific assigned parking spots for the tenant.",
        },
    ],
    "Miscellaneous": [
        {
            machine_name: "severability",
            friendly_name: "Severability",
            description: "Statement that if one part of the lease is invalid, the rest remains in effect",
        },
        {
            machine_name: "entire_agreement",
            friendly_name: "Entire Agreement",
            description: "Statement that the lease constitutes the entire agreement between the parties",
        },
    ],
    "Signatures": [
        {
            machine_name: "landlord_signature",
            friendly_name: "Landlord's Signature",
            description: "Landlord's signature and date",
        },
        {
            machine_name: "tenant_signature",
            friendly_name: "Tenant's Signature",
            description: "Tenant's signature and date",
        },
    ],
    "Additional Provisions": [
        {
            machine_name: "lead_paint_disclosure",
            friendly_name: "Lead-Based Paint Disclosure",
            description: "Required if the property was built before 1978",
        },
        {
            machine_name: "insurance_renters",
            friendly_name: "Renter’s Insurance Requirement",
            description: "Whether tenant must carry renter’s insurance",
        },
    ],
};
