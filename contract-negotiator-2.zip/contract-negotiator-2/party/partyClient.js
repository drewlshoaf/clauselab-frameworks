const axios = require('axios');

// Get party information from command line arguments
const party = process.argv[2];
const changes = process.argv[3] || 'No changes specified.';

// URL of the negotiation service
const url = 'http://localhost:3000/negotiation/update';

// Data for the party (either Party A or Party B)
const requestData = {
  party: party,
  changes: changes
};

async function sendRequest() {
  try {
    const response = await axios.post(url, requestData);
    console.log(`Response for ${party}:`, response.data);
  } catch (error) {
    console.error('Error sending request:', error.response ? error.response.data : error.message);
  }
}

// Validate input
if (!party || (party !== 'partyA' && party !== 'partyB')) {
  console.log('Usage: node partyClient.js <partyA|partyB> [changes]');
  process.exit(1);
}

sendRequest();

