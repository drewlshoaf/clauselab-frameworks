#!/bin/bash

# Output file where all content will be combined
output_file="combined_output.txt"

# Clear the output file before starting (or create it if it doesn't exist)
> "$output_file"
echo "Starting file combination..."

# Use the find command to list all files, excluding node_modules, .sh files, .txt files, and package-lock.json
find . -type f ! -path "*/node_modules/*" ! -name "*.sh" ! -name "*.txt" ! -name "package-lock.json" | while read -r file; do
  echo "Processing file: $file"

  # Append the file path to the output file
  echo "File: $file" >> "$output_file"

  # Add three breaks
  echo "---" >> "$output_file"
  echo "---" >> "$output_file"
  echo "---" >> "$output_file"

  # Append the file's content
  if [[ -f "$file" ]]; then
    cat "$file" >> "$output_file"
  fi
  
  # Append three breaks after the content
  echo -e "\n---\n---\n---" >> "$output_file"

  # Append the file name again for clarity
  echo "File: $file" >> "$output_file"
  echo >> "$output_file"

  # Flush the file buffer to ensure content is being written immediately
  sync

  echo "Finished processing file: $file"
done

echo "All files combined and saved to $output_file"

