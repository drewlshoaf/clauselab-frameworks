#!/bin/bash

# Directory to extract the files
root_dir="contract-negotiator"

# Create the root directory
mkdir -p $root_dir

# Read the combined file and extract each part
while IFS= read -r line; do
  if [[ $line == \#\ BEGIN* ]]; then
    file_path=$(echo $line | sed 's/# BEGIN //')
    mkdir -p "$root_dir/$(dirname "$file_path")"
    echo "Creating $file_path"
    touch "$root_dir/$file_path"
  elif [[ $line == \#\ END* ]]; then
    continue
  else
    echo "$line" >> "$root_dir/$file_path"
  fi
done < contract-negotiator-setup.txt

# Navigate to the engine directory
cd "$root_dir/engine"

# Install dependencies
npm install

echo "Project setup complete!"

