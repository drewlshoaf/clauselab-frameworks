#!/bin/bash

# Directory to create the party clients
party_dir="party"

# Create the party directory if it doesn't exist
mkdir -p "$party_dir"

# Read the combined file and extract each part
while IFS= read -r line; do
  if [[ $line == \#\ BEGIN* ]]; then
    file_path=$(echo $line | sed 's/# BEGIN //' | sed "s/^party\///")
    full_path="$party_dir/$file_path"
    mkdir -p "$(dirname "$full_path")"
    echo "Creating $full_path"
    touch "$full_path"
  elif [[ $line == \#\ END* ]]; then
    continue
  else
    echo "$line" >> "$full_path"
  fi
done < party-setup.txt

# Navigate to the party directory
cd "$party_dir"

# Check if package.json exists
if [[ -f "package.json" ]]; then
  # Install dependencies for the clients
  echo "Running npm install in $party_dir"
  npm install
else
  echo "Error: package.json not found in $party_dir"
  exit 1
fi

echo "Party clients setup complete!"

