import { Router } from 'express';
import { getNegotiation, updateNegotiation } from '../controllers/negotiationController';

const router: Router = Router();

router.get('/', getNegotiation);
router.post('/update', updateNegotiation);

export default router;

