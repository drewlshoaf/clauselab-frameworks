import { Request, Response } from 'express';
import * as fs from 'fs';
import path from 'path';
import { getNextTurn } from '../config/algorithmConfig';

const filePath = path.join(__dirname, '../../shared/negotiation.json');

// Log the current negotiation state
const logNegotiation = (negotiation: any) => {
  console.log('================ Negotiation State ================');
  console.log(`Current Turn: ${negotiation.documentState.turn}`);
  console.log(`Rounds Completed: ${negotiation.documentState.roundsCompleted}`);
  console.log('Proposed Changes:', negotiation.documentState.proposedChanges);
  console.log('===================================================');
};

export const getNegotiation = (req: Request, res: Response) => {
  try {
    const negotiation = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    logNegotiation(negotiation);  // Log the current state of negotiation
    res.status(200).json(negotiation);
  } catch (err) {
    console.error('Error reading negotiation document:', err);
    res.status(500).json({ error: 'Unable to read negotiation document.' });
  }
};

export const updateNegotiation = (req: Request, res: Response) => {
  try {
    const negotiation = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    const currentRound = negotiation.documentState.roundsCompleted;
    const currentTurn = negotiation.documentState.turn;
    const maxRounds = 10;

    // Check if negotiation has exceeded the maximum rounds
    if (currentRound >= maxRounds) {
      console.log(`Request denied: negotiation has ceased after ${maxRounds} rounds.`);
      return res.status(400).json({ message: `Negotiation closed. Maximum rounds of ${maxRounds} reached.` });
    }

    // Check if it's the correct party's turn
    if (req.body.party !== currentTurn) {
      console.log(`Request denied: It's not ${req.body.party}'s turn.`);
      return res.status(400).json({ message: `It's not your turn. It's currently ${currentTurn}'s turn.` });
    }

    // Log the incoming request from the client
    console.log(`Incoming request from ${req.body.party}: ${req.body.changes}`);

    // Determine whose turn it is (Party A or Party B) for the next round
    const updatedNegotiation = {
      ...negotiation,
      documentState: {
        ...negotiation.documentState,
        roundsCompleted: currentRound + 1,
        turn: getNextTurn(currentTurn),
        proposedChanges: [
          ...negotiation.documentState.proposedChanges,
          { by: req.body.party, changes: req.body.changes, timestamp: new Date().toISOString() }
        ]
      }
    };

    // Write updated negotiation back to the file
    fs.writeFileSync(filePath, JSON.stringify(updatedNegotiation, null, 2));

    // Log the updated state of negotiation
    logNegotiation(updatedNegotiation);

    res.status(200).json(updatedNegotiation);
  } catch (err) {
    console.error('Error updating negotiation document:', err);
    res.status(500).json({ error: 'Unable to update negotiation document.' });
  }
};

