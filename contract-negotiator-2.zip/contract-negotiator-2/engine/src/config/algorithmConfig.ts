export const getNextTurn = (currentTurn: string): string => {
  return currentTurn === 'partyA' ? 'partyB' : 'partyA';
};

