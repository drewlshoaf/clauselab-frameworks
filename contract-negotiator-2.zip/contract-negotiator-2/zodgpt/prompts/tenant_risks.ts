import * as fs from 'fs';
import path from 'path';

// Function to generate the prompt for risks to tenants dynamically
export const promptRisksToTenant = (document: string) => {
  return `
    You are a risk analyst providing advice to your client who is considering
    entering into a residential lease agreement.
    You are to analyze the contract and identify 15 risks your client.
    Here is the contract:
    ${document}
  `;
};

