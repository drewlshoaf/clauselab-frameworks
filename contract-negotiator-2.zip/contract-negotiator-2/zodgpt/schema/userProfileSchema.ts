import { z } from 'zod';

// Define the Zod schema for the expected user profile response
export const userProfileSchema = z.object({
  username: z.string().describe('Unique username for the user'),
  fullName: z.string().describe('Full name of the user'),
  bio: z.string().describe('A short biography'),
  age: z.number().int().positive().describe('Age of the user in years'),
  interests: z.array(z.string()).describe('List of user interests'),
  isActive: z.boolean().describe('User activity status'),
});

