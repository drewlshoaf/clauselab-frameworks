import dotenv from 'dotenv';
import { OpenAIChatApi } from 'llm-api';
import { completion } from 'zod-gpt';
import * as fs from 'fs';
import path from 'path';
import util from 'util'; // Importing util for deep object inspection
import { schemaMetadata } from './schema/residential-lease/metadata';
import { promptMetadata } from './prompts/metadata';
import { risksToTenantSchema } from './schema/residential-lease/tenant_risk';
import { promptRisksToTenant } from './prompts/tenant_risks';
import { modelConfig } from './config';
import { v4 as uuidv4 } from 'uuid'; // For generating unique IDs

dotenv.config();

const apiKeyObject = {
  apiKey: process.env.OPENAI_API_KEY || 'API_KEY_NOT_FOUND',
};

if (!process.env.OPENAI_API_KEY) {
  console.error('Error: OPENAI_API_KEY is not set in the environment variables');
  process.exit(1);
}

(async () => {
  try {
    // Logging: Start of process
    console.log('Starting the document analysis process...');

    // Define the path to the contract.txt file
    const filePath = path.join(__dirname, 'contract.txt'); // Adjust the path if necessary

    // Logging: Reading the document from the file system
    console.log('Reading contract.txt from file system...');
    const document = fs.readFileSync(filePath, 'utf-8');

    // Logging: Document content read successfully
    console.log('Successfully read document:', document.substring(0, 100) + '...'); // Log first 100 characters

    const openai = new OpenAIChatApi({ apiKey: process.env.OPENAI_API_KEY }, modelConfig);

    // Generate a unique directory for this process
    const uniqueId = uuidv4();
    const outputDir = path.join(__dirname, 'output', uniqueId);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    // --------- First Request: Extract Metadata ---------
    console.log('Generating metadata extraction prompt...');
    const metadataPrompt = promptMetadata(document); // Function that builds the prompt for metadata extraction
    console.log('Sending document to OpenAI API for metadata extraction...');
    const metadataResponse = await completion(openai, metadataPrompt, {
      schema: schemaMetadata,  // Use the full metadata schema
    });

    console.log('Metadata response received from OpenAI API.');

    // Clean the metadata response and ensure null for missing fields
    const cleanedMetadata = (metadataResponse.data.metadata || []).map((item: any) => ({
      machine_name: item.machine_name || null,
      friendly_name: item.friendly_name || null,
      description: item.description !== '' ? item.description : null, // Set null if description is missing
    }));

    // Identify missing metadata (where description is null)
    const missingMetadata = cleanedMetadata.filter((item: any) => item.description === null);

    // Logging: Missing metadata
    console.log('Missing Metadata:', util.inspect(missingMetadata, { showHidden: false, depth: null, colors: true }));

    // Write the cleaned metadata to the output file
    const metadataOutputFilePath = path.join(outputDir, 'metadata.json');
    fs.writeFileSync(metadataOutputFilePath, JSON.stringify(cleanedMetadata, null, 2), 'utf-8');
    console.log(`Extracted metadata written to ${metadataOutputFilePath}`);

    // Write the missing metadata to a separate file
    const missingMetadataFilePath = path.join(outputDir, 'missing_metadata.json');
    fs.writeFileSync(missingMetadataFilePath, JSON.stringify(missingMetadata, null, 2), 'utf-8');
    console.log(`Missing metadata written to ${missingMetadataFilePath}`);

    // --------- Second Request: Extract Risks to Tenant ---------
    console.log('Generating risk extraction prompt...');

    // Generate a new prompt for extracting risks related to tenants
    const riskPrompt = promptRisksToTenant(document);
    console.log('Sending document to OpenAI API for risk extraction...');
    const riskResponse = await completion(openai, riskPrompt, {
      schema: risksToTenantSchema,  // Use the risk schema for validation
    });
    console.log('Risk response received from OpenAI API.');

    // Clean the risk response and ensure null for missing fields
    const cleanedRisks = (riskResponse.data.risks_to_tenant || []).map((item: any) => ({
      risk: item.risk || null,
      description: item.description !== '' ? item.description : null, // Set null if description is missing
    }));

    // Logging: Full risk details from OpenAI response
    console.log('Extracted Risks to Tenant:', util.inspect(cleanedRisks, { showHidden: false, depth: null, colors: true }));

    // Write the cleaned risks to the output file
    const riskOutputFilePath = path.join(outputDir, 'risks.json');
    fs.writeFileSync(riskOutputFilePath, JSON.stringify(cleanedRisks, null, 2), 'utf-8');
    console.log(`Extracted risks written to ${riskOutputFilePath}`);

    // --------- Third Request: Analyze Missing Metadata Risks ---------
    if (missingMetadata.length > 0) {
      console.log('Generating prompt to analyze missing metadata risks...');

      // Generate a prompt to analyze if missing metadata is a risk
      const missingMetadataPrompt = `The following metadata fields were not found in the document:\n\n${missingMetadata.map(
        (item: any) => `- ${item.friendly_name}\n`
      ).join('')}\n\nIs the absence of these metadata fields a potential risk? Please explain.`;

      console.log('Sending prompt to OpenAI API for missing metadata risk analysis...');
      const missingMetadataResponse = await completion(openai, missingMetadataPrompt);
      console.log('Missing metadata risk analysis response received from OpenAI API.');

      // Save the missing metadata risk analysis to a file
      const missingMetadataRiskOutputFilePath = path.join(outputDir, 'missing_metadata_analysis.json');
      fs.writeFileSync(missingMetadataRiskOutputFilePath, JSON.stringify(missingMetadataResponse.data, null, 2), 'utf-8');
      console.log(`Missing metadata risk analysis written to ${missingMetadataRiskOutputFilePath}`);
    }

  } catch (error) {
    // Logging: Error occurred
    console.error('An error occurred:', error);
  }
})();

