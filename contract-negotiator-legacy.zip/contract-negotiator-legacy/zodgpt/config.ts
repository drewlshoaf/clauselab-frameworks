import { ModelConfig } from './interfaces/ModelConfig';

// Default configuration for ChatGPT-4 model
export const modelConfig: ModelConfig = {
  model: "gpt-4",
  maxTokens: 1000,
  temperature: 0.7,
  topP: 1,
  presencePenalty: 0,
  frequencyPenalty: 0,
  stream: false,
};

