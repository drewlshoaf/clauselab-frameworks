import { z } from 'zod';

// Define the schema for each general risk detail
export const riskDetailSchema = z.object({
  risk: z.string().describe('A general risk associated with the tenant or lease agreement'),
  description: z.string().nullable().describe('A description of the risk, can be null if not found'),
});

// Define the schema for the full risks_to_tenant structure to handle an array of risk details
export const risksToTenantSchema = z.object({
  risks_to_tenant: z.array(riskDetailSchema).describe('An array of risks associated with the lease or tenant'),
});

// Example usage: empty array, to allow the engine to populate as many risks as needed
export const risksToTenant = {
  risks_to_tenant: [],  // No risks hardcoded, ready for dynamic population
};