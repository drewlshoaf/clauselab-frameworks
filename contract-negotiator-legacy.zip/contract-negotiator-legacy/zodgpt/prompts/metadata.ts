import * as fs from 'fs';
import path from 'path';

// Function to generate the prompt dynamically
export const promptMetadata1 = (document: string) => {
  return `
    Extract the following metadata

    - Title: The title of the document, e.g., Residential Lease Agreement.
    - Date: The date when the agreement is made.
    - Landlord Name: Name of the landlord.
    - Tenant Names: Names of the tenant(s).
    - Property Address: Full address, including unit number or specific property description.
    - Type of Property: Type of property (e.g., apartment, single-family home).
    - Start Date: Start date of the lease
    - End Date: End date of the lease
    - Style of home: The style or architecture of the home
    If you can't find any values for a field, then set the description to null.

    from this document: ${document}
  `;
};

export const promptMetadata2 = (document: string) => {
  return `
    Extract the following metadata

    - Storage Provided: Whether storage space is provided as part of the lease.
    - Common Areas Access: Access to shared areas like gyms, pools, or laundry rooms.
    - Common Area Rules: Guidelines for using common areas.
    - Renewal Terms: Conditions for renewal or extension of the lease.
    - Rent Amount: Monthly rent amount.
    - Rent Due Date: When rent is due (e.g., first day of each month).
    - Payment Method: Accepted forms of payment (e.g., check, online transfer).
    - Late Fees: Penalties for late payment, including amount and when they apply.
    - Rent Increase Cap: Maximum allowable percentage for rent increase.
    - Security Deposit Amount: Amount of the security deposit.
    - Conditions for Return: Terms under which the deposit will be returned or withheld.
    - Landlord Responsibilities: What the landlord is responsible for maintaining and repairing.
    - Tenant Responsibilities: What the tenant is responsible for maintaining and repairing.
    - Reporting Issues: How and when the tenant should report maintenance issues.
    - Landscaping Responsibility: Who is responsible for maintaining the yard or landscaping.
    - Pest Control Responsibility: Who is responsible for pest control services.
    - Smoke Detectors: Location and maintenance of smoke detectors.
    - Carbon Monoxide Detectors: Location and maintenance of carbon monoxide detectors.

    If you can't find any values for a field, then set the description to null.

    from this document: ${document}
  `;
};




