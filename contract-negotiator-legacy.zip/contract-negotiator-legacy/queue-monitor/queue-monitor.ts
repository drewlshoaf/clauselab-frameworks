import express, { Request, Response } from 'express';
import { Queue, Job } from 'bullmq';
import IORedis from 'ioredis';

const app = express();
const port = 3001;

// Redis connection
const connection = new IORedis({
  host: 'redis',
  port: 6379,
  maxRetriesPerRequest: null,
});

// Queue names to monitor
const queues = ['convertDocument', 'AITasks'];

// Helper function to get detailed job information
async function getDetailedJobInfo(jobs: Job[]) {
  return jobs.map(job => ({
    id: job.id,
    name: job.name,
    data: job.data,
    attemptsMade: job.attemptsMade,
    processedOn: job.processedOn,
    finishedOn: job.finishedOn,
    timestamp: job.timestamp,
    failedReason: job.failedReason || null,
    stacktrace: job.stacktrace || null,
  }));
}

// Function to get detailed queue information
async function getQueueInfo(queue: Queue) {
  const waiting = await queue.getWaiting();
  const active = await queue.getActive();
  const completed = await queue.getCompleted();
  const failed = await queue.getFailed();

  const detailedWaiting = await getDetailedJobInfo(waiting);
  const detailedActive = await getDetailedJobInfo(active);
  const detailedCompleted = await getDetailedJobInfo(completed);
  const detailedFailed = await getDetailedJobInfo(failed);

  return {
    name: queue.name,
    waitingCount: waiting.length,
    activeCount: active.length,
    completedCount: completed.length,
    failedCount: failed.length,
    waitingJobs: detailedWaiting,
    activeJobs: detailedActive,
    completedJobs: detailedCompleted,
    failedJobs: detailedFailed,
  };
}

// Endpoint to show the status of all queues with detailed job info
app.get('/queues', async (req: Request, res: Response) => {
  try {
    const queueDataPromises = queues.map(queueName => {
      const queue = new Queue(queueName, { connection });
      return getQueueInfo(queue);
    });

    const queueData = await Promise.all(queueDataPromises);
    res.json(queueData);
  } catch (error) {
    console.error('Error fetching queue data:', error);
    res.status(500).send({ error: 'Error fetching queue data' });
  }
});

// Default route
app.get('/', (req: Request, res: Response) => {
  res.send('Queue Monitor is running. Go to /queues to see the queue statuses.');
});

app.listen(port, () => {
  console.log(`Queue monitor service listening at http://localhost:${port}`);
});

