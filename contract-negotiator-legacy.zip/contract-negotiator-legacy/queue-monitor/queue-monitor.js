"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bullmq_1 = require("bullmq");
const ioredis_1 = __importDefault(require("ioredis"));
const app = (0, express_1.default)();
const port = 3001;
// Redis connection
const connection = new ioredis_1.default({
    host: 'redis',
    port: 6379,
    maxRetriesPerRequest: null,
});
// Queue names to monitor
const queues = ['convertDocument', 'AITasks'];
// Helper function to get detailed job information
function getDetailedJobInfo(jobs) {
    return __awaiter(this, void 0, void 0, function* () {
        return jobs.map(job => ({
            id: job.id,
            name: job.name,
            data: job.data,
            attemptsMade: job.attemptsMade,
            processedOn: job.processedOn,
            finishedOn: job.finishedOn,
            timestamp: job.timestamp,
            failedReason: job.failedReason || null,
            stacktrace: job.stacktrace || null,
        }));
    });
}
// Function to get detailed queue information
function getQueueInfo(queue) {
    return __awaiter(this, void 0, void 0, function* () {
        const waiting = yield queue.getWaiting();
        const active = yield queue.getActive();
        const completed = yield queue.getCompleted();
        const failed = yield queue.getFailed();
        const detailedWaiting = yield getDetailedJobInfo(waiting);
        const detailedActive = yield getDetailedJobInfo(active);
        const detailedCompleted = yield getDetailedJobInfo(completed);
        const detailedFailed = yield getDetailedJobInfo(failed);
        return {
            name: queue.name,
            waitingCount: waiting.length,
            activeCount: active.length,
            completedCount: completed.length,
            failedCount: failed.length,
            waitingJobs: detailedWaiting,
            activeJobs: detailedActive,
            completedJobs: detailedCompleted,
            failedJobs: detailedFailed,
        };
    });
}
// Endpoint to show the status of all queues with detailed job info
app.get('/queues', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const queueDataPromises = queues.map(queueName => {
            const queue = new bullmq_1.Queue(queueName, { connection });
            return getQueueInfo(queue);
        });
        const queueData = yield Promise.all(queueDataPromises);
        res.json(queueData);
    }
    catch (error) {
        console.error('Error fetching queue data:', error);
        res.status(500).send({ error: 'Error fetching queue data' });
    }
}));
// Default route
app.get('/', (req, res) => {
    res.send('Queue Monitor is running. Go to /queues to see the queue statuses.');
});
app.listen(port, () => {
    console.log(`Queue monitor service listening at http://localhost:${port}`);
});
