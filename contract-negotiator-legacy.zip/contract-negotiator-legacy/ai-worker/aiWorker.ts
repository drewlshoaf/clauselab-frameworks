import { Worker, FlowProducer } from 'bullmq';
import IORedis from 'ioredis';

// Redis connection
const connection = new IORedis({
  host: 'redis',
  port: 6379,
  maxRetriesPerRequest: null
});

// FlowProducer to handle job dependencies and flow control
const flowProducer = new FlowProducer({ connection });

// Worker for documentInit queue to handle the document initialization process
const documentInitWorker = new Worker(
  'documentInit',  // Listen for jobs on the documentInit queue
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Document Init] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);

    try {
      // Start with MetaValidation, then proceed to parallel tasks if successful
      await flowProducer.add({
        name: 'meta-validation-flow',
        queueName: 'metaValidation',
        data: { clientId, negotiationId, fileId },
        children: [
          // Parallel Tasks (meta-extraction, structured-risk, inferred-risk)
          {
            name: 'parallel-tasks',
            queueName: 'parallelTasks',
            data: { clientId, negotiationId, fileId },
            children: [
              // Meta Extraction (3 parallel tasks)
              { name: 'meta-extract-1', queueName: 'metaExtract', data: { clientId, negotiationId, fileId }},
              { name: 'meta-extract-2', queueName: 'metaExtract', data: { clientId, negotiationId, fileId }},
              { name: 'meta-extract-3', queueName: 'metaExtract', data: { clientId, negotiationId, fileId }},
              
              // Structured Risk Extraction (3 parallel tasks)
              { name: 'structured-risk-extract-1', queueName: 'structuredRiskExtract', data: { clientId, negotiationId, fileId }},
              { name: 'structured-risk-extract-2', queueName: 'structuredRiskExtract', data: { clientId, negotiationId, fileId }},
              { name: 'structured-risk-extract-3', queueName: 'structuredRiskExtract', data: { clientId, negotiationId, fileId }},
              
              // Inferred Risk Extraction (2 parallel tasks)
              { name: 'inferred-risk-extract-1', queueName: 'inferredRiskExtract', data: { clientId, negotiationId, fileId }},
              { name: 'inferred-risk-extract-2', queueName: 'inferredRiskExtract', data: { clientId, negotiationId, fileId }}
            ]
          }
        ]
      });

      console.log(`[Document Init] Meta Validation and parallel tasks started for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);

      // Only after all parallel tasks (meta, structured, inferred) are done, run final structured risk tasks
      await flowProducer.add({
        name: 'final-structured-risk-task',
        queueName: 'structuredRiskExtract',
        data: { clientId, negotiationId, fileId },
        children: [
          { name: 'final-structured-risk-1', queueName: 'structuredRiskExtract', data: { clientId, negotiationId, fileId }},
          { name: 'final-structured-risk-2', queueName: 'structuredRiskExtract', data: { clientId, negotiationId, fileId }}
        ]
      });

      console.log(`[Document Init] All tasks completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    } catch (error: any) {
      console.error(`[Document Init] Error occurred: ${error.message}`);
    }
  },
  { connection }
);

// Meta Validation Worker
const metaValidationWorker = new Worker(
  'metaValidation',
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Meta Validation] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    // Simulate meta validation logic
    console.log(`[Meta Validation] Completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
  },
  { connection }
);

// Meta Extraction Worker
const metaExtractWorker = new Worker(
  'metaExtract',
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Meta Extraction] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    // Simulate meta extraction logic
    console.log(`[Meta Extraction] Completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
  },
  { connection }
);

// Structured Risk Extraction Worker
const structuredRiskWorker = new Worker(
  'structuredRiskExtract',
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Structured Risk Extraction] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    // Simulate structured risk extraction logic
    console.log(`[Structured Risk Extraction] Completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
  },
  { connection }
);

// Inferred Risk Extraction Worker
const inferredRiskWorker = new Worker(
  'inferredRiskExtract',
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Inferred Risk Extraction] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    // Simulate inferred risk extraction logic
    console.log(`[Inferred Risk Extraction] Completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
  },
  { connection }
);

// Final Structured Risk Worker
const finalStructuredRiskWorker = new Worker(
  'structuredRiskExtract',
  async (job) => {
    const { clientId, negotiationId, fileId } = job.data;

    console.log(`[Final Structured Risk] Starting for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
    // Simulate final structured risk extraction logic
    console.log(`[Final Structured Risk] Completed for clientId: ${clientId}, negotiationId: ${negotiationId}, fileId: ${fileId}`);
  },
  { connection }
);

// Task completion/failure logging
documentInitWorker.on('completed', (job) => {
  console.log(`[Document Init] Job ${job.id} completed.`);
});
metaValidationWorker.on('completed', (job) => {
  console.log(`[Meta Validation] Job ${job.id} completed.`);
});
metaExtractWorker.on('completed', (job) => {
  console.log(`[Meta Extraction] Job ${job.id} completed.`);
});
structuredRiskWorker.on('completed', (job) => {
  console.log(`[Structured Risk Extraction] Job ${job.id} completed.`);
});
inferredRiskWorker.on('completed', (job) => {
  console.log(`[Inferred Risk Extraction] Job ${job.id} completed.`);
});
finalStructuredRiskWorker.on('completed', (job) => {
  console.log(`[Final Structured Risk] Job ${job.id} completed.`);
});

documentInitWorker.on('failed', (job, err) => {
  console.error(`[Document Init] Job ${job.id} failed with error: ${err.message}`);
});
metaValidationWorker.on('failed', (job, err) => {
  console.error(`[Meta Validation] Job ${job.id} failed with error: ${err.message}`);
});
metaExtractWorker.on('failed', (job, err) => {
  console.error(`[Meta Extraction] Job ${job.id} failed with error: ${err.message}`);
});
structuredRiskWorker.on('failed', (job, err) => {
  console.error(`[Structured Risk Extraction] Job ${job.id} failed with error: ${err.message}`);
});
inferredRiskWorker.on('failed', (job, err) => {
  console.error(`[Inferred Risk Extraction] Job ${job.id} failed with error: ${err.message}`);
});
finalStructuredRiskWorker.on('failed', (job, err) => {
  console.error(`[Final Structured Risk] Job ${job.id} failed with error: ${err.message}`);
});
