declare module 'pdf-parse' {
    interface PDFDocumentProxy {
        numPages: number;
        getPage: (pageNumber: number) => Promise<PDFPageProxy>;
    }

    interface PDFPageProxy {
        getTextContent: () => Promise<TextContent>;
    }

    interface TextContent {
        items: Array<{ str: string }>;
    }

    interface PDFParseResult {
        numpages: number;
        numrender: number;
        info: object;
        metadata: object;
        text: string;
        version: string;
    }

    function pdf(data: Buffer | Uint8Array | ArrayBuffer): Promise<PDFParseResult>;

    export = pdf;
}

