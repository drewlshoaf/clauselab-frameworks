import express from 'express';
import partyRoutes from './routes/partyRoutes';
import documentRoutes from './routes/documentRoutes';

// Create an instance of Express app
const app = express();

// Middleware
app.use(express.json()); // Parse incoming JSON requests

// Routes
app.use('/parties', partyRoutes);
app.use('/documents', documentRoutes);

// Export the app for use in other files (e.g., server.ts or tests)
export default app;

