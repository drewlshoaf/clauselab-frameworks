import { Request, Response } from 'express';
import { ObjectId } from 'mongodb';  // Import ObjectId for converting string to MongoDB ObjectId
import { connectToDatabase } from '../services/mongoService';

// Create a new party
export async function createParty(req: Request, res: Response) {
    const db = await connectToDatabase();
    const parties = db.collection('parties');
  
    const newParty = {
        name: req.body.name,
        company: req.body.company,
        email: req.body.email,
        negotiations: []  // Empty array for negotiations
    };

    const result = await parties.insertOne(newParty);
    res.status(201).send({ partyId: result.insertedId });
}

// Fetch a party by MongoDB _id
export async function getParty(req: Request, res: Response) {
    const db = await connectToDatabase();
    const parties = db.collection('parties');

    const partyId = req.params.partyId;

    // Convert the string partyId to ObjectId
    try {
        const party = await parties.findOne({ _id: new ObjectId(partyId) });

        if (party) {
            res.status(200).send(party);
        } else {
            res.status(404).send({ message: 'Party not found' });
        }
    } catch (error) {
        res.status(400).send({ message: 'Invalid Party ID' });
    }
}

// Add a new negotiation to a party
export async function addNegotiation(req: Request, res: Response) {
    const db = await connectToDatabase();
    const parties = db.collection('parties');

    const partyId = req.params.partyId;
    const negotiation = req.body;

    // Convert the string partyId to ObjectId
    try {
        const result = await parties.updateOne(
            { _id: new ObjectId(partyId) },  // Match by ObjectId
            { $push: { negotiations: negotiation } }
        );

        if (result.modifiedCount > 0) {
            res.status(201).send({ negotiationId: negotiation.negotiationId });
        } else {
            res.status(404).send({ message: 'Party not found' });
        }
    } catch (error) {
        res.status(400).send({ message: 'Invalid Party ID' });
    }
}

// Add feedback to a specific negotiation
export async function addFeedback(req: Request, res: Response) {
    const db = await connectToDatabase();
    const parties = db.collection('parties');

    const partyId = req.params.partyId;
    const negotiationId = req.params.negotiationId;
    const feedback = req.body;

    // Convert the string partyId to ObjectId
    try {
        const result = await parties.updateOne(
            { _id: new ObjectId(partyId), 'negotiations.negotiationId': negotiationId },
            { $push: { 'negotiations.$.feedbacks': feedback } }
        );

        if (result.modifiedCount > 0) {
            res.status(201).send({ feedbackId: feedback.feedbackId });
        } else {
            res.status(404).send({ message: 'Negotiation not found' });
        }
    } catch (error) {
        res.status(400).send({ message: 'Invalid Party ID' });
    }
}

// Get details of a specific negotiation
export async function getNegotiation(req: Request, res: Response) {
    const db = await connectToDatabase();
    const parties = db.collection('parties');

    const partyId = req.params.partyId;
    const negotiationId = req.params.negotiationId;

    // Convert the string partyId to ObjectId
    try {
        const party = await parties.findOne(
            { _id: new ObjectId(partyId), 'negotiations.negotiationId': negotiationId },
            { projection: { 'negotiations.$': 1 } }
        );

        if (party && party.negotiations && party.negotiations.length > 0) {
            res.status(200).send(party.negotiations[0]);
        } else {
            res.status(404).send({ message: 'Negotiation not found' });
        }
    } catch (error) {
        res.status(400).send({ message: 'Invalid Party ID' });
    }
}

