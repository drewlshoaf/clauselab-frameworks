import { Request, Response } from 'express';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import fs from 'fs/promises';
import path from 'path';
import pdfParse from 'pdf-parse';

// Redis connection configuration
const connection = new IORedis({
  host: 'redis',
  port: 6379,
  maxRetriesPerRequest: null,
});

// POST /document - Processes the uploaded PDF and converts it to text
export const uploadDocument = async (req: Request, res: Response) => {
  console.log('Starting PDF to text conversion...');

  try {
    const { clientId, negotiationId } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).send({ message: 'No file received for upload.' });
    }

    // The file path where the uploaded PDF is stored
    const pdfFilePath = file.path;

    console.log(`Processing PDF at path: ${pdfFilePath}`);

    // Read the PDF file from the disk
    const pdfBuffer = await fs.readFile(pdfFilePath);

    // Convert the PDF to text using pdf-parse
    const pdfData = await pdfParse(pdfBuffer);
    const textContent = pdfData.text;

    console.log('PDF text conversion completed.');

    // Write the text output to the same directory as the PDF, but with a .txt extension
    const textFilePath = pdfFilePath.replace('.pdf', '.txt');
    await fs.writeFile(textFilePath, textContent);

    console.log(`Text file created at path: ${textFilePath}`);

    // Add the job to the AITasks queue
    const fileId = path.parse(file.filename).name; // Unique file identifier (without extension)
    const AIQueue = new Queue('documentInit', { connection });
    await AIQueue.add('documentInit', { clientId, negotiationId, fileId });

    // Respond to the client with success
    res.status(200).send({
      message: 'Document uploaded and converted to text successfully. Processing will continue.',
      fileId,
      textFilePath, // Return the path of the text file
    });
  } catch (error: any) {
    console.error('Error processing document:', error);
    res.status(500).send({
      message: 'Error processing document',
      error: error.message,
    });
  }
};

