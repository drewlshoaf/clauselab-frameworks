import { Router } from 'express';
import multer from 'multer';  // Middleware for handling file uploads
import { uploadDocument } from '../controllers/documentController';
import { promises as fs } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';  // Import uuid for generating unique GUIDs

const router = Router();

// Set up Multer to handle file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const clientId = req.body.clientId;
    const negotiationId = req.body.negotiationId;
    const dir = path.join(__dirname, `../shared/${clientId}/${negotiationId}/`);

    // Create the directory if it doesn't exist
    fs.mkdir(dir, { recursive: true })
      .then(() => cb(null, dir))
      .catch((err) => cb(err as Error, dir));  // Explicitly cast err to Error
  },
  filename: (req, file, cb) => {
    if (!req.fileId) {  // Ensure the UUID is generated only once
      req.fileId = uuidv4();  // This now works with the extended Request type
    }
    const fileId = req.fileId;  // Reuse the generated UUID
    cb(null, `${fileId}.pdf`);
  }
});

const upload = multer({ storage });

// POST route for uploading documents
router.post('/', upload.single('pdf'), uploadDocument);

export default router;
