import { Router } from 'express';
import { createParty, getParty, addNegotiation, addFeedback, getNegotiation } from '../controllers/partyController';

const router = Router();

// Routes for party management
router.post('/', createParty);  // Create a new party
router.get('/:partyId', getParty);  // Fetch a party by ID

// Routes for negotiations
router.post('/:partyId/negotiations', addNegotiation);  // Add a negotiation to a party
router.get('/:partyId/negotiations/:negotiationId', getNegotiation);  // Fetch a negotiation
router.post('/:partyId/negotiations/:negotiationId/feedback', addFeedback);  // Add feedback to a negotiation

export default router;

