import app from './app';  // Import the app from app.ts
import { config } from './config/config';

// Start the server and bind it to the port
const PORT = config.server.port || 3000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

