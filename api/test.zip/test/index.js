// Import the pg library using require (CommonJS syntax)
const { Client } = require('pg');

// PostgreSQL connection details (hard-coded for simplicity)
const client = new Client({
  host: 'clauselab-mvp-db-instance.c6qzyl5ezsdp.us-east-1.rds.amazonaws.com',  // Replace with your RDS endpoint
  port: 5432,
  user: 'clauselab',    // Replace with your DB username
  password: 'welcome123',   // Replace with your DB password
  database: 'clauselabmvp'    // Replace with your DB name
});

// Lambda handler function
exports.handler = async (event) => {
  try {
    // Connect to the PostgreSQL database
    await client.connect();
    console.log('Connected to PostgreSQL database successfully!');

    // Run a simple query
    const res = await client.query('SELECT NOW()');
    console.log(res.rows[0]);

    // Close the connection
    await client.end();

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Database connection successful!',
        timestamp: res.rows[0].now,
      }),
    };
  } catch (err) {
    console.error('Failed to connect to PostgreSQL database:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Database connection failed!',
        error: err.message,
      }),
    };
  }
};
