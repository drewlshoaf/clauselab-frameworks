import * as AWS from "aws-sdk";
import { randomUUID } from "crypto";
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { Client } from 'pg';  // Using 'pg' for PostgreSQL integration

const { S3_BUCKET, PRESIGNED_URL_EXPIRES, PG_HOST, PG_PORT, PG_USER, PG_PASSWORD, PG_DATABASE } = process.env;

const s3 = new AWS.S3();

// Setup PostgreSQL client as `null` or `Client`
let pgClient: Client | null = null;

const connectToPostgres = async () => {
  if (!pgClient) {
    pgClient = new Client({
      host: PG_HOST,
      port: parseInt(PG_PORT || '5432', 10),
      user: PG_USER,
      password: PG_PASSWORD,
      database: PG_DATABASE,
    });

    await pgClient.connect();
  }
};

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    // Connect to PostgreSQL
    await connectToPostgres();

    if (event.httpMethod === "OPTIONS") {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://localhost:3000",
          "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
          "Access-Control-Allow-Methods": "OPTIONS,POST"
        },
        body: JSON.stringify({})
      };
    }

    if (!event.body) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://localhost:3000"
        },
        body: JSON.stringify({ error: 'Invalid request, no body found' })
      };
    }

    const { account } = JSON.parse(event.body);

    if (!account) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: 'Invalid request, account parameter is required' })
      };
    }

    // Check if account exists in the database
    const accountCheckResult = await pgClient!.query('SELECT id FROM account WHERE id = $1', [account]);

    if (accountCheckResult.rows.length === 0) {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: 'Account not found' })
      };
    }

    // Account exists, generate new doc ID and insert it into the doc table
    const docId = randomUUID();
    await pgClient!.query(
      'INSERT INTO doc (id, account_id, state) VALUES ($1, $2, $3)',
      [docId, account, 'purl_requested']
    );

    // Prepare the pre-signed S3 URL
    const documentKey = `${account}/${docId}/1.pdf`;
    const documentParams = {
      Bucket: S3_BUCKET as string,
      Key: documentKey,
      Expires: parseInt(PRESIGNED_URL_EXPIRES || '3600', 10),
      ContentType: 'application/pdf'
    };

    const documentUrl = s3.getSignedUrl('putObject', documentParams);

    return {
      isBase64Encoded: false,
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ docId, documentUrl })
    };
  } catch (error: any) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: 'Internal Server Error', details: error.message })
    };
  } finally {
    if (pgClient) {
      // Close the PostgreSQL connection after the Lambda invocation is done
      await pgClient.end();
      pgClient = null; // Reset the client for future invocations
    }
  }
};
