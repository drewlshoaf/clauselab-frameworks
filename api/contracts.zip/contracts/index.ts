import { S3 } from '@aws-sdk/client-s3'; // Updated AWS SDK v3
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { Readable } from 'stream';

const s3 = new S3();
const { S3_BUCKET } = process.env;

interface DoctypeResponse {
  statusCode: number;
  headers: {
    "Content-Type": string;
    "Access-Control-Allow-Origin": string;
  };
  body: string;
}

// Utility to convert the Body into a string (handling ReadableStream)
const streamToString = (stream: Readable): Promise<string> => {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on('data', chunk => chunks.push(Buffer.from(chunk)));
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
    stream.on('error', reject);
  });
};

const getDoctypes = async (): Promise<DoctypeResponse> => {
  // Define the S3 key and params
  const s3Key = 'sysdocs/contracts.json';  // Corrected the typo
  const params = {
    Bucket: S3_BUCKET as string,
    Key: s3Key,
  };

  // Log S3 bucket and file details for debugging
  console.log(`Fetching file from S3`);
  console.log(`S3 Bucket: ${S3_BUCKET}`);
  console.log(`S3 Key: ${s3Key}`);
  console.log(`Full path: s3://${S3_BUCKET}/${s3Key}`);

  try {
    const data = await s3.getObject(params);
    console.log('S3 getObject response:', data);

    let doctypes: any;
    
    if (data.Body instanceof Readable) {
      const bodyString = await streamToString(data.Body);
      doctypes = JSON.parse(bodyString);
    } else if (data.Body instanceof Uint8Array) {
      doctypes = JSON.parse(Buffer.from(data.Body).toString('utf-8'));
    } else {
      throw new Error('Unsupported body type');
    }

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(doctypes),
    };
  } catch (error) {
    console.error('Error fetching doctypes from S3:', error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: 'Failed to fetch doctypes', details: error.message }),
    };
  }
};

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  return await getDoctypes();
};
