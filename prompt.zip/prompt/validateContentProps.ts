import { contractCodes } from "../services/loadContractsJson";

export const getPromptValidateContentProps = async (contractText: string) => {

    const contractTypeCodes = await contractCodes();

    return `
      Please examine this document:
      
      ${contractText}
      
      and return a JSON response with the following fields:
  
      1. **isLegible**: Analyze the text content of the attached PDF and determine if the text is readable. Return true if it is legible, otherwise return false.
      
      2. **percentLegible**: Estimate the percentage (from 0 to 100) of the document's text that is readable.
      
      3. **isAContract**: Determine whether the document's text constitutes a contract. Return true if the document is a contract, otherwise return false.
      
      4. **percentContract**: Estimate the percentage (from 0 to 100) of the document that is part of a contract.
      
      5. **contractTypeCode**: Identify the type of contract the document represents by comparing it against this list: 
      
      ${contractTypeCodes}
      
      If no match is found, return null, otherwise, return the code which best represents the contract type.
      
      6. **language**: Identify the primary language used in the document.
      Please provide the result in the following JSON format:
  
      {
        "isLegible": boolean,
        "percentLegible": number,
        "isAContract": boolean,
        "percentContract": number,
        "contractTypeCode": string | null,
        "language": string,
      }
    `;
  };
  