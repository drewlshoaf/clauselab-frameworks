
  const promptResidentialLeaseAgreement = (contractText: string) => {

    return `
    Analyze this document and make a report, using the JSON template below.
  
    Try not to use too much hyperbole. You can be friendly, but you need to be objective. 
  
    Here is a sample report in JSON format. Please keep the JSON format and the keys like they are, but change the values
    based on your analysis. Anything marked as (Example) should be replaced with your own dynamic values.
  
    ***
    jsonGPTMessage": {
      "title": "Unlock the Full Potential of Your Lease Agreement with DontSign.ai!",
      "header": (Example)Congratulations on taking the first step towards securing your home at 401 Meadowbrook Road, Charlotte, NC. Our comprehensive analysis of your Residential Lease Agreement has identified crucial areas that require your attention to ensure a smooth and secure rental experience.",
      "keyQuestionsSection": {
          "keyQuestionsHeader": We found some concerns you'll want to address,
          "keyQuestions": [
              In this section, you should find some concerns and note them here, but don't be too specific, along with a promise on how we will address them in our full report. Note at least 5 major concerns/promises.
              (Example) "It looks like their's some ambiguity in the maintenance responsiblities. We'll help identify these issues and give you some real practical
              advice and example language to help you clarify and resolve these matters".
          ]
      },
      "mainSection": {
          "highlightsHeader": "Key Highlights of Our Full Analysis:",
          "highlights": [
              {
                  "title": "High Risks Identified",
                  "text": "Learn about significant risks like early lease termination clauses and ambiguous maintenance responsibilities that could impact your tenancy."
              },
              {
                  "title": "Detailed Risk Mitigation",
                  "text": "Receive in-depth recommendations on how to negotiate better terms and safeguard your interests."
              },
              {
                  "title": "Comprehensive Data Extraction",
                  "text": "Gain insights into essential contract components, including rent terms, security deposit conditions, and maintenance responsibilities."
              },
              {
                  "title": "Expert Advice Tailored to Your Needs",
                  "text": "Benefit from personalized guidance to navigate complex lease terms and avoid potential pitfalls."
              }
          ]
      },
      "footer": {
          "text": "Our full analysis provides a thorough evaluation, ensuring you are fully informed and protected before signing. From identifying hidden risks to offering actionable solutions, DontSign.ai is your trusted partner in making confident, informed decisions.\n\nReady to secure your peace of mind? Unlock the complete analysis now and take control of your rental journey with confidence and clarity. Don't leave your future to chance—let DontSign.ai guide you every step of the way."
      }
      ***
  
    Here is the Residential Lease Agreement
    ***
    ${contractText}
    ***
  
    Return a JSON object like this:
  
    Only return the JSON response. Do not return any additional information, or context, or acknowledgement.
    `;
  };

export { promptResidentialLeaseAgreement };

