import { Job } from 'bullmq';
import { Db } from 'mongodb';
import { OpenAIChatApi } from 'llm-api';
import { modelConfig } from '../config/modelConfig';
import { completion } from 'zod-gpt';
import { storyMakerSchema } from '../schema/storyMaker';
import { promptStory } from '../prompts/storyMaker';
import { questionMaker } from '../queues/questionMaker';

// OpenAI setup
const openai = new OpenAIChatApi({ apiKey: process.env.OPENAI_API_KEY }, modelConfig);

export async function storyMakerJob(job: Job, db: Db) {
  const { negotiation_id } = job.data;

  try {
    const negotiationsCollection = db.collection('negotiations');

    // Check if the negotiation exists
    const negotiation = await negotiationsCollection.findOne({ negotiation_id });
    if (!negotiation) {
      throw new Error(`Negotiation with ID ${negotiation_id} not found`);
    }

    // Generate story prompt for each party
    const storyMakerPrompt = promptStory(negotiation.negotiation_type, negotiation.parties);
    const storyMakerGPTResponse = await completion(openai, storyMakerPrompt, { schema: storyMakerSchema });

    // Loop through the response and update only the story field for the matched parties
    for (const responseParty of storyMakerGPTResponse.data.parties) {
      const { party_id, story } = responseParty;

      // Find the matching party in the existing negotiation document
      const partyIndex = negotiation.parties.findIndex(
        (p: { name: string; party_id: string; role: string }) =>
          p.party_id === party_id
      );

      if (partyIndex === -1) {
        console.warn(`No matching party found for party_id: ${party_id}`);
        continue;
      }

      // Update the story field for the matched party
      await negotiationsCollection.updateOne(
        { negotiation_id, [`parties.${partyIndex}.party_id`]: party_id },
        { $set: { [`parties.${partyIndex}.story`]: story } }
      );
      console.log(`Updated story for party ${party_id} in negotiation ${negotiation_id}`);

      // Add a message to the questionMakerQueue for each party with a new story
      await questionMaker.add('createQuestion', {
        negotiation_id,
        party_id
      });
      console.log(`Added job to questionMakerQueue for party ${party_id}`);
    }
  } catch (error) {
    console.error(`Failed to process job: ${(error as Error).message}`);
  }
}
