import { Job } from 'bullmq';
import { Db } from 'mongodb';
import { OpenAIChatApi } from 'llm-api';
import { modelConfig } from '../config/modelConfig';
import { completion } from 'zod-gpt';
import { questionMakerSchema } from '../schema/questionMaker';
import { questionMakerPrompt } from '../prompts/questionMaker';
import { v4 as uuidv4 } from 'uuid'; // Importing UUID

// OpenAI setup
const openai = new OpenAIChatApi({ apiKey: process.env.OPENAI_API_KEY }, modelConfig);

export async function questionMakerJob(job: Job, db: Db) {
  const { negotiation_id, party_id } = job.data;

  try {
    const negotiationsCollection = db.collection('negotiations');

    // Fetch the negotiation document
    const negotiation = await negotiationsCollection.findOne({ negotiation_id });
    if (!negotiation) {
      throw new Error(`Negotiation with negotiation_id ${negotiation_id} not found`);
    }

    const formatPartiesForPrompt = (parties: Array<{ name: string; party_id: string; role: string; story: string }>): string => {
      return parties
        .map((party) => `Name: ${party.name}, Role: ${party.role}, Story: "${party.story}"`)
        .join("\n");
    };

    // Generate the questions prompt based on the party's story
    const questionPrompt = questionMakerPrompt(negotiation.negotiation_type, formatPartiesForPrompt(negotiation.parties), party_id);
    console.log('questionPrompt', questionPrompt);

    // Send prompt to OpenAI for question generation
    try {
      const questionResponse = await completion(openai, questionPrompt, { schema: questionMakerSchema });
      const question_text = questionResponse.data.question || questionResponse.data; // Handle as a single question string

      // Prepare the question to be added to the party's questions array
      const newQuestion = {
        question_id: uuidv4(),
        question_text,
      };

      // Check if the `questions` array exists for the given party
      const party = negotiation.parties.find((p: { party_id: string }) => p.party_id === party_id);
      if (!party) {
        throw new Error(`Party with party_id ${party_id} not found in negotiation ${negotiation_id}`);
      }

      // If `questions` doesn't exist, initialize it with the new question
      if (!party.questions) {
        await negotiationsCollection.updateOne(
          { negotiation_id, 'parties.party_id': party_id },
          { $set: { 'parties.$.questions': [newQuestion] } }
        );
      } else {
        // Otherwise, push the new question to the existing `questions` array
        await negotiationsCollection.updateOne(
          { negotiation_id, 'parties.party_id': party_id },
          { $push: { 'parties.$.questions': newQuestion } }
        );
      }

      console.log('Updated negotiation with new question:', newQuestion);
    } catch (validationError) {
      console.error('Failed Zod validation:', validationError);
    }
  } catch (error) {
    console.error(`Failed to process job: ${(error as Error).message}`);
  }
}
