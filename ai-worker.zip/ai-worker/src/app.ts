import 'dotenv/config'; // Load environment variables
import { questionMakerWorker } from './workers/questionMaker';
import { storyMakerWorker } from './workers/storyMaker';
import { redisConfig } from './config/redisConfig';
import { initMongoConnection } from './config/db';
import { Job } from 'bullmq';

(async () => {
  try {
    // Initialize MongoDB connection
    const db = await initMongoConnection();

    // Workers initialization
    const questionWorker = questionMakerWorker(redisConfig, db);
    const storyWorker = storyMakerWorker(redisConfig, db);

    // Worker event listeners
    questionWorker.on('completed', (job: Job) => {
      console.log(`Help Us Resolve Question job ${job.id} completed.`);
    });
    questionWorker.on('failed', (job: Job, err: Error) => {
      console.error(`Help Us Resolve Question job ${job.id} failed: ${err.message}`);
    });

    storyWorker.on('completed', (job: Job) => {
      console.log(`Auto Agent Story Maker job ${job.id} completed.`);
    });
    storyWorker.on('failed', (job: Job, err: Error) => {
      console.error(`Auto Agent Story Maker job ${job.id} failed: ${err.message}`);
    });

    console.log('All workers are initialized and running...');

  } catch (error) {
    console.error('Failed to initialize application:', error);
    process.exit(1);
  }
})();
