// Define the Party type for better type checking
type Party = {
    party_id: string;
    role: string;
  };
  
  // Update the function to use the Party type for the parties argument
  export function promptStory(negotiation_type: string, parties: Party[]): string {
    const partyDescriptions = parties
      .map(party => `- ${party.party_id} (${party.role})`)
      .join('\n');
    
    return `You are a story telling system that generates stories about conflicts between parties. 
    Your job is to come up with a common conflict scenario in the area of ${negotiation_type}. 
    You will develop 1000 word stories for each party to the conflict. 
    The parties involved are:  ${partyDescriptions}. 
    This means the story for each side must be at least 1000 words, each.
    Your stories will be told in the 1st person.
    Your stories will assume the conflict is a present conflict.
    Your response will be returned in a json structured response according to the schema 
    provided in this request.
    `;
  }
  