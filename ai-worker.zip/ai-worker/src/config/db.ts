import { MongoClient, Db } from 'mongodb';

const MONGO_URI = process.env.MONGO_URI || 'mongodb://mongo:27017';
const client = new MongoClient(MONGO_URI);

// export async function initMongoConnection(): Promise<Db> {
//   if (!client.isConnected()) {
//     await client.connect();
//   }
//   return client.db('mydatabase');
// }

export async function initMongoConnection() {
  if (!client) {
    throw new Error('MongoClient is not initialized.');
  }

  if (!client.db().databaseName) {
    await client.connect();
  }

  return client.db('mydatabase');
}


