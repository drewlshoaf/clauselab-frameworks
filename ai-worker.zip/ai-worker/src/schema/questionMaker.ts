import { z } from 'zod';

export const questionMakerSchema = z.object({
  question: z.string().describe('The question text'), 
})
