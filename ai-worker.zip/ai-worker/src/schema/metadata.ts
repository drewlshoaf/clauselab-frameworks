import { z } from 'zod';

// Define the schema for each meta detail, allowing description to be either string or null
export const metaDetailSchema = z.object({
  machine_name: z.string().describe('The machine-readable name for the metadata item'),
  friendly_name: z.string().describe('The human-readable name for the metadata item'),
  description: z.string().nullable().describe('A description of the metadata item or null if not provided'),
});

// Define the schema for the full metadata structure as an object, not an array
export const schemaMetadata1 = z.object({
  metadata1: z.array(metaDetailSchema),
});

export const schemaMetadata2 = z.object({
  metadata1: z.array(metaDetailSchema),
});

// Example usage: this is the flattened metadata
export const metadata1 = {
  metadata: [
    {
      machine_name: 'title',
      friendly_name: 'Title',
      description: 'The title of the document, e.g., Residential Lease Agreement',
    },
    {
      machine_name: 'date',
      friendly_name: 'Date',
      description: 'The date when the agreement is made',
    },
    {
      machine_name: 'landlord_name',
      friendly_name: 'Landlord Name',
      description: 'Name of the landlord',
    },
    {
      machine_name: 'tenant_names',
      friendly_name: 'Tenant Names',
      description: 'Names of the tenant(s)',
    },
    {
      machine_name: 'property_address',
      friendly_name: 'Property Address',
      description: 'Full address, including unit number or specific property description',
    },
    {
      machine_name: 'type_of_property',
      friendly_name: 'Type of Property',
      description: 'Type of property (e.g., apartment, single-family home)',
    },
    {
      machine_name: 'start_date',
      friendly_name: 'Start Date',
      description: 'When the lease begins',
    },
    {
      machine_name: 'end_date',
      friendly_name: 'End Date',
      description: 'When the lease ends',
    }
  ],
};

export const metadata2 = {
  metadata: [
    {
      machine_name: 'storage_provided',
      friendly_name: 'Storage Provided',
      description: 'Whether storage space is provided as part of the lease',
    },
    {
      machine_name: 'common_area_access',
      friendly_name: 'Common Areas Access',
      description: 'Access to shared areas like gyms, pools, or laundry rooms',
    },
    {
      machine_name: 'renewal_terms',
      friendly_name: 'Renewal Terms',
      description: 'Conditions for renewal or extension of the lease',
    },
    {
      machine_name: 'rent_amount',
      friendly_name: 'Rent Amount',
      description: 'Monthly rent amount',
    },
    {
      machine_name: 'due_date',
      friendly_name: 'Rent Due Date',
      description: 'When rent is due (e.g., first day of each month)',
    },
    {
      machine_name: 'payment_method',
      friendly_name: 'Payment Method',
      description: 'Accepted forms of payment (e.g., check, online transfer)',
    },
    {
      machine_name: 'late_fees',
      friendly_name: 'Late Fees',
      description: 'Penalties for late payment, including amount and when they apply',
    },
    {
      machine_name: 'rent_increase_limit',
      friendly_name: 'Rent Increase Cap',
      description: 'Maximum allowable percentage for rent increase',
    },
    {
      machine_name: 'security_deposit_amount',
      friendly_name: 'Security Deposit Amount',
      description: 'Amount of the security deposit',
    },
    {
      machine_name: 'landscaping_responsibility',
      friendly_name: 'Landscaping Responsibility',
      description: 'Who is responsible for maintaining the yard or landscaping',
    },
    {
      machine_name: 'pest_control_responsibility',
      friendly_name: 'Pest Control Responsibility',
      description: 'Who is responsible for pest control services',
    },
    {
      machine_name: 'fire_safety_smoke_detectors',
      friendly_name: 'Smoke Detectors',
      description: 'Existance of and maintenance of maintenance of smoke detectors',
    },
    {
      machine_name: 'carbon_monoxide_detectors',
      friendly_name: 'Carbon Monoxide Detectors',
      description: 'Existance of and maintenance of carbon monoxide detectors',
    }
  ],
};
