import { z } from 'zod';

// Define the Zod schema for a feedback response with parties
export const storyMakerSchema = z.object({
  parties: z.array(  // An array of parties involved
    z.object({
      party_id: z.string().describe('The ID of the party'),  // Party ID is required// Party role is required
      story: z.string().describe('The story or narrative provided by the party')  // Party story is required
    })
  ).describe('An array of parties involved in the feedback')
}).describe('The feedback response object');