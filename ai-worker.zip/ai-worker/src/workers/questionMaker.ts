import { Worker, Job } from 'bullmq';
import { Db } from 'mongodb';
import { questionMakerJob } from '../jobs/questionMaker';
import { redisConfigType } from '../config/redisConfig';

export function questionMakerWorker(redisConfig: redisConfigType, db: Db) {
  return new Worker('questionMaker', async (job: Job) => {
    console.log('Processing Help Us Resolve Question job:', job.data);
    await questionMakerJob(job, db);
  }, { connection: redisConfig });
}

