import { Worker, Job } from 'bullmq';
import { Db } from 'mongodb';
import { storyMakerJob } from '../jobs/storyMaker';
import { redisConfigType } from '../config/redisConfig';

export function storyMakerWorker(redisConfig: redisConfigType, db: Db) {
  return new Worker('storyMaker', async (job: Job) => {
    console.log('Processing Auto Agent Story Maker job:', job.data);
    await storyMakerJob(job, db);
  }, { connection: redisConfig });
}

