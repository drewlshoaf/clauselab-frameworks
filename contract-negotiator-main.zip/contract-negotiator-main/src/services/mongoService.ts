import { MongoClient } from 'mongodb';
import { config } from '../config/config';

let client: MongoClient;

export async function connectToDatabase() {
  if (!client) {
    client = new MongoClient(config.database.connectionString);
    await client.connect();
    console.log('Connected to MongoDB');
  }
  return client.db(config.database.dbName);
}

