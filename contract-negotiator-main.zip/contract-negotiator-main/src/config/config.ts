import * as dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

export const config = {
  database: {
    connectionString: process.env.MONGO_URI || 'mongodb://localhost:27017/negotiator',
    dbName: process.env.MONGO_DB_NAME || 'negotiator',
  },
  server: {
    port: process.env.PORT || 3000,
  },
  jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret',  // Example of sensitive value
};

