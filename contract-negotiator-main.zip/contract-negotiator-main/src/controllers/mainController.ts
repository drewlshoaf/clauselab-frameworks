import { Request, Response } from 'express';
import { Queue, Worker } from 'bullmq';
import IORedis from 'ioredis';

// Redis connection configuration
const connection = new IORedis({
  host: 'redis',  // Change to 'localhost' if you are not using Docker
  port: 6379,
  maxRetriesPerRequest: null  // This is the fix to comply with BullMQ
});

// Define your queues
const documentConversionQueue = new Queue('documentConversion', { connection });
const chatGptMetaValidationQueue = new Queue('chatGptMetaValidation', { connection });
const metaTasksQueue = new Queue('metaTasks', { connection });
const riskTasksQueue = new Queue('riskTasks', { connection });

// POST /document
export async function uploadDocument(req: Request, res: Response) {
    const { clientId, negotiationId } = req.body;
    const fileId = req.fileId;  // Assuming you're using Multer for file handling

    try {
        // Step 1: Add document conversion job to the queue
        await documentConversionQueue.add('convertDocument', { clientId, negotiationId, fileId });

        // Step 2: Define workers for further tasks
        const chatGptMetaValidationWorker = new Worker('documentConversion', async job => {
            console.log(`Document conversion complete for fileId: ${job.data.fileId}`);
            await chatGptMetaValidationQueue.add('validateMeta', job.data);
        }, { connection });

        const metaValidationWorker = new Worker('chatGptMetaValidation', async job => {
            console.log(`ChatGPT meta validation complete for fileId: ${job.data.fileId}`);
            await Promise.all([
                metaTasksQueue.add('metaLevel1', { ...job.data, level: 1 }),
                metaTasksQueue.add('metaLevel2', { ...job.data, level: 2 }),
                metaTasksQueue.add('metaLevel3', { ...job.data, level: 3 })
            ]);
        }, { connection });

        const metaTasksWorker = new Worker('metaTasks', async job => {
            console.log(`Meta task Level ${job.data.level} complete for fileId: ${job.data.fileId}`);
            if (job.data.level === 3) {
                await Promise.all([
                    riskTasksQueue.add('riskLevel1', { ...job.data, level: 1 }),
                    riskTasksQueue.add('riskLevel2', { ...job.data, level: 2 }),
                    riskTasksQueue.add('riskLevel3', { ...job.data, level: 3 })
                ]);
            }
        }, { connection });

        const riskTasksWorker = new Worker('riskTasks', async job => {
            console.log(`Risk task Level ${job.data.level} complete for fileId: ${job.data.fileId}`);
            if (job.data.level === 3) {
                console.log(`All tasks completed for fileId: ${job.data.fileId}`);
            }
        }, { connection });

        // Respond immediately to the client
        res.status(200).send({ message: 'Document uploaded successfully. Processing will continue.', fileId });
    } catch (error: any) {
        console.error('Error processing document:', error);
        res.status(500).send({ message: 'Error processing document', error: error.message });
    }
}
