import { parentPort, workerData } from 'worker_threads';
import { promises as fs } from 'fs';
import path from 'path';
import pdfParse from 'pdf-parse';  // For converting PDF to text

// Function to process the document (PDF to text conversion)
async function processDocument({ clientId, negotiationId, fileId }: { clientId: string, negotiationId: string, fileId: string }) {
    try {
        // Define paths to the PDF and output text files
        const pdfFilePath = path.join(__dirname, `../shared/${clientId}/${negotiationId}/${fileId}.pdf`);
        const textFilePath = path.join(__dirname, `../shared/${clientId}/${negotiationId}/${fileId}.txt`);

        // Read the PDF file
        const pdfData = await fs.readFile(pdfFilePath);
        const extractedText = await pdfParse(pdfData);

        // Write the extracted text to a .txt file
        await fs.writeFile(textFilePath, extractedText.text);

        // Send a success message back to the parent thread
        parentPort?.postMessage({ status: 'success', fileId });
    } catch (error) {
        // Send an error message back to the parent thread
        parentPort?.postMessage({ status: 'error', message: (error as Error).message });
    }
}

// Start processing the document when the worker is created
processDocument(workerData);

