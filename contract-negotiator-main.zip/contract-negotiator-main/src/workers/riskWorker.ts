import { workerData, parentPort } from 'worker_threads';

async function processRisk() {
    const { clientId, negotiationId, fileId, level } = workerData;

    try {
        // Simulate some processing delay for the task
        console.log(`Risk Worker - Level ${level} started for fileId: ${fileId}, clientId: ${clientId}, negotiationId: ${negotiationId}`);

        // Simulate delay to mimic work (e.g., 1 second per level)
        await new Promise((resolve) => setTimeout(resolve, 1000 * level));

        // Acknowledge completion
        console.log(`Risk Worker - Level ${level} completed for fileId: ${fileId}`);

        // Send success response back to the parent thread
        parentPort?.postMessage({ status: 'success', level, result: `Risk level ${level} completed` });
    } catch (error) {
        parentPort?.postMessage({ status: 'error', message: (error as Error).message });
    }
}

// Start processing the risk task
processRisk();

