import { Request } from 'express';

declare global {
    namespace Express {
        interface Request {
            fileId?: string;  // Add the fileId property to the Request interface
        }
    }
}

