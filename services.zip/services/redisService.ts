import redisClient from './redisClient';

export const setRedisKey = (key: string, value: string): Promise<string> => redisClient.set(key, value);
export const getRedisKey = (key: string): Promise<string | null> => redisClient.get(key);