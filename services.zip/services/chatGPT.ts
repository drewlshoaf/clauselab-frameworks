// Import the OpenAI class from the SDK
import OpenAI from 'openai';

// Define the type for OpenAI response message
interface OpenAIMessage {
  role: string;
  content: string | null;  // Allow null for content
}

// Define the type for OpenAI response choices
interface OpenAIChoice {
  message: OpenAIMessage;
}

// Define the type for the OpenAI API response
interface OpenAIResponse {
  choices: OpenAIChoice[];
}

// Logging utilities (replace with your logger, if available)
// const logInfo = (message: string, data: any) => console.log(message, data);
// const logError = (message: string, error: any) => console.error(message, error);

// Configure OpenAI client with the API key from environment variables
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY as string,  // Type assertion to ensure string
});

/**
 * Fetches a response from OpenAI's chat model with retry logic and response concatenation.
 * 
 * @param {string} prompt - The prompt to send to the OpenAI API.
 * @param {string} preSignedUrl - The pre-signed URL to include in the prompt for OpenAI to download the file.
 * @returns {Promise<string>} - A concatenated string response from the API.
 */
export const fetchOpenAIResponse = async (prompt: string): Promise<string> => {
  const responses: string[] = [];
  let done = false;
  let cursor: number | null = null;
  let retryCount = 0;

  // Configuration variables from environment
  const maxRetries = parseInt(process.env.MAX_RETRIES || '3');
  const maxTokens = parseInt(process.env.MAX_TOKENS || '1500');
  const model = process.env.OPENAI_MODEL || 'gpt-3.5-turbo';

  while (!done && retryCount < maxRetries) {
    try {
      const openaiResponse = await openai.chat.completions.create({
        model: model,
        messages: [{
          role: 'user',
          content: prompt,
        }],
        max_tokens: maxTokens,
      });

      const gptResponse = openaiResponse.choices[0]?.message.content?.trim() || '';  // Check for null or undefined
      responses.push(gptResponse);
      // logInfo(`OpenAI response part ${cursor || 1}:`, gptResponse);

      if (gptResponse.endsWith('```')) {
        done = true;
      } else if (gptResponse.length >= maxTokens) {
        cursor = (cursor || 1) + 1;  // Continue with the next part if message length is maxed out
        retryCount++;
      } else {
        done = true;
      }
    } catch (error: any) {
      // logError(`Error during OpenAI API call:`, error);

      // If error is 401 Unauthorized, don't retry
      if (error.status === 401 || error.code === 'AuthenticationError') {
        // logError('Invalid API key or authentication issue. Aborting retries.', error);
        throw new Error('Authentication failed. Check your API key.');
      }

      retryCount++;
      if (retryCount >= maxRetries) {
        throw new Error('Max retries reached.');
      }
    }
  }

  // Always return a concatenated response string
  return responses.join(' ').trim() || "No meaningful response generated.";
};
