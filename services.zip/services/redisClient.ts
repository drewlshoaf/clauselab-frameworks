import Redis from 'ioredis';

const redisUrl = process.env.REDIS_URL || 'redis://redis:6379';

const maxRetries = parseInt(process.env.REDIS_MAX_RETRIES || '5', 10);
const retryDelay = parseInt(process.env.REDIS_RETRY_DELAY || '1000', 10);

const redisClient = new Redis(redisUrl, {
  retryStrategy: (times) => {
    if (times >= maxRetries) {
      console.error(`Max retries reached: ${times}. Could not connect to Redis.`);
      return null;
    }
    
    const delay = retryDelay * times;
    console.log(`Retry attempt #${times}. Retrying in ${delay} ms...`);
    return delay;
  },
  
  reconnectOnError: (err) => {
    const targetError = "READONLY";
    if (err.message.includes(targetError)) {
      return true;
    }
    return false;
  }
});

redisClient.on('connect', () => {
  console.log('Connected to Redis successfully.');
});

redisClient.on('error', (err) => {
  console.error('Redis error:', err);
});

export default redisClient;

