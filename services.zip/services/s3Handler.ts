import { S3, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { Readable } from 'stream';
import fs from 'fs';
import path from 'path';
import { pipeline } from 'stream/promises';

// Initialize S3 client
const s3 = new S3({ region: 'us-east-1' });

/**
 * Fetch S3 metadata for a specific object.
 * 
 * @param {string} bucket - The S3 bucket name.
 * @param {string} key - The object key in the bucket.
 * @returns {Promise<any>} - The metadata of the object.
 */
export const getS3Metadata = async (bucket: string, key: string): Promise<any> => {
  try {
    const metadata = await s3.headObject({ Bucket: bucket, Key: key });
    // console.log(`S3 Metadata for key ${key}:`, metadata);
    return metadata;
  } catch (err) {
    console.error(`Failed to get S3 metadata for ${key}:`, err);
    throw err;
  }
};

/**
 * Generate a pre-signed URL for an S3 object.
 * 
 * @param {string} bucket - The S3 bucket name.
 * @param {string} key - The object key for which to generate the URL.
 * @param {number} expiresIn - The expiration time for the pre-signed URL in seconds (e.g., 3600 for 1 hour).
 * @returns {Promise<string>} - The pre-signed URL for the object.
 */
export const generatePreSignedUrl = async (bucket: string, key: string, expiresIn: number = 3600): Promise<string> => {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const signedUrl = await getSignedUrl(s3, command, { expiresIn });
    // console.log(`Pre-signed URL for key ${key}:`, signedUrl);
    return signedUrl;
  } catch (err) {
    console.error(`Failed to generate pre-signed URL for ${key}:`, err);
    throw err;
  }
};

/**
 * Downloads an S3 text file and returns its content as a string.
 * 
 * @param {string} bucket - The S3 bucket name.
 * @param {string} key - The object key to download.
 * @returns {Promise<string>} - The content of the file as a string.
 */
export const downloadS3TextFileToMemory = async (bucket: string, key: string): Promise<string> => {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3.send(command);

    if (!response.Body) {
      throw new Error('No file content received.');
    }

    const fileContent = await streamToString(response.Body as Readable);
    // console.log('File content downloaded successfully');
    return fileContent;
  } catch (err) {
    console.error(`Failed to download S3 text file for ${key}:`, err);
    throw err;
  }
};

/**
 * Helper function to convert a Readable stream into a string.
 * 
 * @param {Readable} stream - The readable stream to convert.
 * @returns {Promise<string>} - The content of the stream as a string.
 */
const streamToString = async (stream: Readable): Promise<string> => {
  const chunks: Uint8Array[] = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf-8');
};

/**
 * Download an S3 object and save it to a local file.
 * 
 * @param {string} bucket - The S3 bucket name.
 * @param {string} key - The object key to download.
 * @param {string} downloadPath - The local file path where the file will be saved.
 * @returns {Promise<void>} - Resolves when the file is successfully downloaded.
 */
export const downloadS3File = async (bucket: string, key: string, downloadPath: string): Promise<void> => {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3.send(command);

    if (!response.Body) {
      throw new Error('No file content received.');
    }

    // Ensure the download directory exists
    const dirPath = path.dirname(downloadPath);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }

    // Create a writable stream and pipe the S3 object to the local file
    const writeStream = fs.createWriteStream(downloadPath);
    await pipeline(response.Body as any, writeStream);

    // console.log(`File downloaded successfully to ${downloadPath}`);
  } catch (err) {
    // console.error(`Failed to download S3 file for ${key}:`, err);
    throw err;
  }
};

/**
 * Uploads a local file to S3.
 * 
 * @param {string} source - The path to the local file to upload.
 * @param {string} bucket - The S3 bucket name.
 * @param {string} key - The object key (path) to upload the file to in S3.
 * @returns {Promise<void>} - Resolves when the file is successfully uploaded.
 */
export const uploadS3File = async (source: string, bucket: string, key: string): Promise<void> => {
  try {
    // Check if the file exists
    if (!fs.existsSync(source)) {
      throw new Error(`File not found at ${source}`);
    }

    // Read the content of the file
    const fileContent = fs.readFileSync(source);

    // Create the upload command
    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: fileContent,
      ContentType: 'text/plain'
    });

    // Upload the file to S3
    await s3.send(command);
    // console.log(`File uploaded successfully to s3://${bucket}/${key}`);
  } catch (err) {
    console.error(`Failed to upload file to S3: ${source} -> s3://${bucket}/${key}`, err);
    throw err;
  }
};