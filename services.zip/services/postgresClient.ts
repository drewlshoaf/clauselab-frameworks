import { Pool, PoolClient, QueryResult } from 'pg';

// Define types for PostgreSQL client configuration
interface PostgresConfig {
  user: string;
  host: string;
  database: string;
  password: string;
  port: number;
  connectionTimeoutMillis: number;
  idleTimeoutMillis: number;
  maxRetries: number;
  retryDelay: number;
}

// Define the configuration object with explicit types
const config: PostgresConfig = {
  user: process.env.POSTGRES_USER || 'drew',
  host: process.env.POSTGRES_HOST || 'localhost',
  database: process.env.POSTGRES_DB || 'clauselab',
  password: process.env.POSTGRES_PASSWORD || 'welcome123',
  port: parseInt(process.env.POSTGRES_PORT || '5432', 10),
  connectionTimeoutMillis: parseInt(process.env.POSTGRES_CONN_TIMEOUT || '2000', 10),  // 2 seconds timeout
  idleTimeoutMillis: 10000,  // 10 seconds before the client is considered idle
  maxRetries: 3,  // Maximum number of retries
  retryDelay: 1000,  // Delay between retries in milliseconds
};

// Create a new PostgreSQL pool with the config
const pool: Pool = new Pool(config);

// Retry logic for connection attempts
const connectWithRetry = async (retries: number, delay: number): Promise<PoolClient | null> => {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const client = await pool.connect();
      console.log('Connected to PostgreSQL successfully.');
      return client;
    } catch (err) {
      console.error(`PostgreSQL connection attempt ${attempt} failed. Retrying in ${delay} ms...`);
      if (attempt === retries) {
        console.error('Max retries reached. Failing the connection attempt.');
        return null;
      }
      await new Promise(res => setTimeout(res, delay));
    }
  }
  return null;
};

// Event listener for successful connection
pool.on('connect', (client: PoolClient): void => {
  console.log('Connected to the PostgreSQL database.');
});

// Event listener for errors
pool.on('error', (err: Error, client: PoolClient): void => {
  console.error('Error in PostgreSQL client:', err.message);
  process.exit(-1);
});

// Example function to query users with proper return types
export const getUsers = async (): Promise<QueryResult<any>> => {
  const client = await connectWithRetry(config.maxRetries, config.retryDelay);
  
  if (!client) {
    throw new Error('Failed to connect to PostgreSQL after multiple attempts');
  }

  try {
    const res: QueryResult<any> = await client.query('SELECT * FROM users');
    return res;  // Return query result
  } catch (err: unknown) {
    if (err instanceof Error) {
      console.error('Error executing query:', err.message);
    } else {
      console.error('Unknown error occurred.');
    }
    throw err;
  } finally {
    client.release();  // Release the client back to the pool
  }
};

export default pool;
