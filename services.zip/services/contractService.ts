import { downloadS3TextFileToMemory } from './s3Service';

let contractCodes: string;

export const loadContractsJson = async (): Promise<void> => {
  const contractsKey = 'sysdocs/contracts.json';
  const bucketName = process.env.S3_BUCKET_NAME || '';

  try {
    const fileContent = await downloadS3TextFileToMemory(bucketName, contractsKey);
    const contractsData = JSON.parse(fileContent);
    contractCodes = Array.from(new Set(contractsData.contracts.map((contract: any) => contract.code))).join(',');
  } catch (err) {
    console.error('Failed to load contracts.json into memory', err);
    throw err;
  }
};

export const getContractCodes = (): string => contractCodes;